#include "StatusLED.h"

namespace {
  // Il LED RGB onboard di questa scheda e' cablato attivo-basso:
  // LOW = acceso, HIGH = spento (verificato empiricamente: la macro
  // LED_STATE_ON del board package e' fuorviante per questa variante).
  //
  // I canali non hanno la stessa luminosita' percepita a parita' di
  // corrente (il rosso "domina" visivamente sul verde) - per questo il
  // giallo e' pilotato via PWM (analogWrite) con il rosso attenuato,
  // invece di accendere entrambi i canali a piena intensita' in digitale.
  // RED_MIX_BRIGHTNESS e' l'unico valore da ritoccare se il giallo non è
  // ancora bilanciato bene: piu' basso = meno rosso/più verdastro, piu'
  // alto = piu' arancione. Range valido 0-255.
  const uint8_t RED_MIX_BRIGHTNESS = 30;
  const uint8_t FULL_BRIGHTNESS = 255;

  // brightness: 0 = spento, 255 = massima luminosita'. Inverte la
  // convenzione PWM standard perche' il pin e' attivo-basso.
  void setChannel(uint32_t pin, uint8_t brightness) {
    analogWrite(pin, 255 - brightness);
  }

  void setRGB(uint8_t red, uint8_t green, uint8_t blue) {
    setChannel(LED_RED, red);
    setChannel(LED_GREEN, green);
    setChannel(LED_BLUE, blue);
  }

  void red() { setRGB(FULL_BRIGHTNESS, 0, 0); }
  void green()  { setRGB(0, FULL_BRIGHTNESS, 0); }
  void blue()   { setRGB(0, 0, FULL_BRIGHTNESS); }
  void off_()   { setRGB(0, 0, 0); }

  const unsigned long BLINK_INTERVAL_MS = 500;
  unsigned long lastBlinkTime = 0;
  bool blinkOn = false;
}

void StatusLED::begin() {
  analogWriteResolution(8);
  off_();
}

void StatusLED::update(bool connected, bool calibrated, bool trackingActive) {
  if (!connected) {
    unsigned long now = millis();
    if (now - lastBlinkTime >= BLINK_INTERVAL_MS) {
      lastBlinkTime = now;
      blinkOn = !blinkOn;
    }
    if (blinkOn) red(); else off_();
    return;
  }

  if (!calibrated) {
    red();
  } else if (trackingActive) {
    blue();
  } else {
    green();
  }
}

void StatusLED::off() { off_(); }
