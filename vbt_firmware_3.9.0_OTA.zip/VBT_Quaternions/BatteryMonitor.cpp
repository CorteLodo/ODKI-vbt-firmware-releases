#include "BatteryMonitor.h"
#include <InternalFileSystem.h>

using namespace Adafruit_LittleFS_Namespace;

namespace {
  const float VBAT_MV_PER_LSB   = 0.73242188f; // 3.0V fondo scala (AR_INTERNAL_3_0), ADC 12 bit -> 3000/4096
  // Compensazione del partitore VBAT. Ritarata dopo il fix di
  // analogSampleTime() (la taratura precedente, 2.6953, compensava in
  // parte il bias sistematico dell'ADC dovuto al TACQ insufficiente, non
  // solo il vero rapporto del partitore - non piu' valida una volta
  // corretto il TACQ). Nuova taratura: firmware leggeva 3.78V con
  // batteria dichiarata al 100% (~4.20V, il punto di piena carica della
  // curva in voltageToPercent) -> 2.6953 * (4.20/3.78) = 2.9948. Resta il
  // valore di fabbrica/baseline condiviso da TUTTI i dispositivi: la
  // AUTO-CALIBRAZIONE sotto corregge poi lo scarto residuo SPECIFICO di
  // ciascuna scheda (tolleranza dei componenti del partitore), quindi non
  // dovrebbe piu' servire ritararlo a mano da qui in avanti - vedi sotto.
  const float VBAT_DIVIDER_COMP = 3.055918f;  //2.9948f;

  const int OVERSAMPLE_COUNT = 8; // media di piu' letture ADC per ridurre il rumore del convertitore

  // Media mobile esponenziale tra una lettura e la successiva (chiamate a
  // ~30s di distanza, vedi Config::BATTERY_CHECK_INTERVAL_MS): smorza cali
  // di tensione momentanei sotto carico (es. burst radio BLE) senza
  // rendere il valore troppo lento a seguire un vero cambio di carica.
  // Alpha piu' basso = piu' stabile ma piu' lento a inseguire il valore vero.
  const float EMA_ALPHA = 0.3f;
  float smoothedVoltage = -1.0f; // -1 = nessuna lettura ancora fatta

  // ============================================================================
  // AUTO-CALIBRAZIONE per-dispositivo, usando il LED di carica come
  // riferimento noto.
  //
  // Il chip di carica della XIAO nRF52840 Sense (BQ25100) espone il suo
  // stato su D23 (P0.17, nome "~CHG" nel variant.cpp del board package) -
  // lo STESSO segnale che accende il LED di carica onboard: attivo BASSO
  // (LOW = carica in corso, LED acceso; rilasciato/HIGH = non in carica,
  // LED spento - o perche' la carica e' COMPLETA, o perche' manca
  // alimentazione USB/batteria). Confermato dal pin map ufficiale Seeed
  // (wiki.seeedstudio.com/XIAO_BLE, "CHARGE_LED -> P0.17") e da
  // variant.cpp del board package ("D23 is P0.17 (~CHG)").
  //
  // Il solo ~CHG non basta a distinguere "carica completata" da "USB
  // scollegato" (in ENTRAMBI i casi il pin passa a HIGH) - serve quindi
  // anche NRF_POWER->USBREGSTATUS (VBUSDETECT), un registro hardware
  // dell'nRF52840 che riflette la presenza di alimentazione USB
  // indipendentemente dal chip di carica: se VBUS e' ancora presente
  // quando ~CHG passa da attivo a rilasciato, la carica e' davvero
  // arrivata a termine (non e' stato scollegato nulla). Gia' usato con
  // successo nello stesso identico modo in Bluefruit52Lib (bluefruit.cpp).
  //
  // Al momento di quella transizione, la batteria e' per definizione alla
  // tensione di fine carica del BQ25100 (4.20V standard per una cella
  // LiPo/Li-ion singola, coerente con la curva in voltageToPercent sotto)
  // - un riferimento noto e affidabile, migliore di qualunque taratura
  // manuale una tantum: si ricalcola quindi un fattore di correzione
  // MOLTIPLICATIVO (calFactor, applicato sopra VBAT_DIVIDER_COMP) che
  // porta la lettura corrente esattamente a 4.20V, e lo si persiste in
  // flash (InternalFS/LittleFS) cosi' da sopravvivere al reset completo
  // che ogni deep sleep provoca (vedi PowerManager::goToSleep()) - senza
  // persistenza la calibrazione imparata durante la carica andrebbe
  // sempre persa prima della sessione di allenamento successiva, vanificando
  // lo scopo.
  //
  // Guardrail contro un evento spurio (rumore sul pin, richiesta durante un
  // blip di ricollegamento USB, ecc.):
  //   - CHARGING_CONFIRM_CHECKS: la carica deve essere stata rilevata attiva
  //     per ALMENO queste letture consecutive (a cadenza ~30s) prima che una
  //     sua conclusione venga considerata attendibile.
  //   - CAL_FACTOR_MIN/MAX: il fattore risultante deve restare entro
  //     +-15% - oltre e' quasi certamente un problema hardware/lettura
  //     anomala, non un vero scarto di tolleranza del partitore; in quel
  //     caso la calibrazione viene scartata (non salvata) invece di
  //     corrompere il valore buono gia' persistito.
  // ============================================================================
  const uint8_t PIN_CHG_STATUS = 23; // D23 = P0.17 = ~CHG del BQ25100, vedi sopra

  const char* CAL_FILE_PATH = "/battcal.dat";
  const uint32_t CAL_FILE_MAGIC = 0x42435631UL; // "BCV1", verifica che il file non sia vuoto/di un altro formato
  struct PersistedCal {
    uint32_t magic;
    float calFactor;
  };

  const float FULL_CHARGE_VOLTAGE = 4.20f;
  const float CAL_FACTOR_MIN = 0.85f;
  const float CAL_FACTOR_MAX = 1.15f;
  const uint8_t CHARGING_CONFIRM_CHECKS = 3; // ~90s+ di carica confermata prima di fidarsi di una sua conclusione

  float calFactor = 1.0f; // 1.0 = nessuna correzione ancora imparata, si parte dal solo VBAT_DIVIDER_COMP
  bool wasChgActive = false;
  uint8_t chargingConfirmedChecks = 0;

  void loadCalFactor() {
    InternalFS.begin();
    File f(InternalFS);
    if (f.open(CAL_FILE_PATH, FILE_O_READ)) {
      PersistedCal pc;
      bool ok = (f.read(&pc, sizeof(pc)) == (int)sizeof(pc)) &&
                (pc.magic == CAL_FILE_MAGIC) &&
                (pc.calFactor >= CAL_FACTOR_MIN) && (pc.calFactor <= CAL_FACTOR_MAX);
      f.close();
      if (ok) {
        calFactor = pc.calFactor;
        Serial.print("BatteryMonitor: fattore di calibrazione caricato da flash: ");
        Serial.println(calFactor, 4);
      }
    }
  }

  void saveCalFactor(float newFactor) {
    File f(InternalFS);
    if (f.open(CAL_FILE_PATH, FILE_O_WRITE)) {
      PersistedCal pc;
      pc.magic = CAL_FILE_MAGIC;
      pc.calFactor = newFactor;
      f.write((const uint8_t*)&pc, sizeof(pc));
      f.close();
    } else {
      Serial.println("BatteryMonitor: ERRORE, impossibile salvare la calibrazione su flash.");
    }
  }

  // Aggiorna calFactor se questo campione segna la fine di una carica vera
  // (vedi commento su AUTO-CALIBRAZIONE sopra) - chiamata da readVoltage()
  // ad ogni lettura (~30s, vedi Config::BATTERY_CHECK_INTERVAL_MS), con
  // smoothedVoltage gia' aggiornato con la lettura corrente.
  void updateAutoCalibration() {
    bool chgActive = BatteryMonitor::isCharging();
    bool vbusPresent = (NRF_POWER->USBREGSTATUS & POWER_USBREGSTATUS_VBUSDETECT_Msk) != 0;

    if (chgActive && chargingConfirmedChecks < 255) {
      chargingConfirmedChecks++;
    }

    if (wasChgActive && !chgActive && vbusPresent &&
        chargingConfirmedChecks >= CHARGING_CONFIRM_CHECKS && smoothedVoltage > 0.5f) {
      float candidateFactor = calFactor * (FULL_CHARGE_VOLTAGE / smoothedVoltage);
      if (candidateFactor >= CAL_FACTOR_MIN && candidateFactor <= CAL_FACTOR_MAX) {
        calFactor = candidateFactor;
        saveCalFactor(calFactor);
        // Riflette subito la nuova calibrazione, senza aspettare che l'EMA
        // (tarata per smorzare il rumore, non per un salto voluto) la
        // raggiunga da sola in qualche lettura futura - siamo appena stati
        // avvisati dall'hardware stesso che QUESTA e' la tensione di piena
        // carica.
        smoothedVoltage = FULL_CHARGE_VOLTAGE;
        Serial.print("BatteryMonitor: carica completata (~CHG rilasciato, USB ancora presente), "
                      "auto-calibrazione applicata. Nuovo fattore: ");
        Serial.println(calFactor, 4);
      } else {
        Serial.print("BatteryMonitor: calibrazione automatica scartata (fattore ");
        Serial.print(candidateFactor, 4);
        Serial.println(" fuori dal range plausibile +-15%).");
      }
    }

    if (!chgActive) {
      chargingConfirmedChecks = 0;
    }
    wasChgActive = chgActive;
  }
}

void BatteryMonitor::begin() {
  pinMode(VBAT_ENABLE, OUTPUT);
  digitalWrite(VBAT_ENABLE, HIGH); // partitore scollegato finche' non serve leggere
  analogReference(AR_INTERNAL_3_0);
  analogReadResolution(12);

  // Il partitore VBAT e' ad altissima impedenza (~350k ohm effettivi, vedi
  // VBAT_DIVIDER_COMP). Il tempo di acquisizione di default dell'SAADC
  // (3us) basta solo per sorgenti a bassa impedenza: con una sorgente cosi'
  // "lenta" il condensatore di campionamento interno non fa in tempo a
  // caricarsi alla vera tensione del nodo, producendo un bias sistematico
  // (non rumore casuale - per questo oversampling/EMA da soli non
  // bastavano). 40us (il massimo permesso da questo core) da' margine
  // ampio per una sorgente di questa impedenza.
  analogSampleTime(40);

  // Nessun pull-up esterno noto sul ~CHG (vedi commento su AUTO-CALIBRAZIONE
  // sopra): INPUT_PULLUP garantisce comunque un HIGH definito quando il
  // BQ25100 lo rilascia (open-drain), invece di lasciarlo fluttuante.
  pinMode(PIN_CHG_STATUS, INPUT_PULLUP);

  loadCalFactor();
}

bool BatteryMonitor::isCharging() {
  return digitalRead(PIN_CHG_STATUS) == LOW; // ~CHG attivo basso, vedi commento su AUTO-CALIBRAZIONE sopra
}

// Riabilita il partitore solo per il tempo della lettura, poi lo richiude
// (protegge il pin ADC e riduce il consumo del partitore in standby).
// La tensione ritornata e' oversampled (media di piu' campioni ADC
// ravvicinati), filtrata nel tempo (EMA rispetto alla lettura precedente)
// e corretta dal fattore di auto-calibrazione per-dispositivo (calFactor,
// vedi commento su AUTO-CALIBRAZIONE sopra).
float BatteryMonitor::readVoltage() {
  digitalWrite(VBAT_ENABLE, LOW);
  delay(1); // assestamento del partitore dopo l'abilitazione

  uint32_t rawSum = 0;
  for (int i = 0; i < OVERSAMPLE_COUNT; i++) {
    rawSum += analogRead(PIN_VBAT);
  }
  float rawAvg = (float)rawSum / OVERSAMPLE_COUNT;

  digitalWrite(VBAT_ENABLE, HIGH);

  float instantVoltage = (rawAvg * VBAT_MV_PER_LSB * VBAT_DIVIDER_COMP * calFactor) / 1000.0f;

  if (smoothedVoltage < 0.0f) {
    smoothedVoltage = instantVoltage; // prima lettura in assoluto: niente da smorzare ancora
  } else {
    smoothedVoltage = EMA_ALPHA * instantVoltage + (1.0f - EMA_ALPHA) * smoothedVoltage;
  }

  updateAutoCalibration();

  return smoothedVoltage;
}

// Curva LiPo semplificata a due tratti (0% a 3.30V, 10% a 3.60V, poi
// lineare fino a 100% a 4.20V circa).
float BatteryMonitor::voltageToPercent(float volts) {
  float mvolts = volts * 1000.0f;
  if (mvolts < 3300.0f) return 0.0f;
  if (mvolts < 3600.0f) {
    return (mvolts - 3300.0f) / 30.0f;
  }
  float pct = 10.0f + (mvolts - 3600.0f) * 0.15f;
  return pct > 100.0f ? 100.0f : pct;
}
