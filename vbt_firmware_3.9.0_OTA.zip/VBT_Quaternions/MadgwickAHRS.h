#ifndef MADGWICK_AHRS_H
#define MADGWICK_AHRS_H

#include <Arduino.h>

// Filtro di Madgwick 6DOF (fusione accelerometro + giroscopio, nessun
// magnetometro). Algoritmo standard, dominio pubblico
// (Sebastian O.H. Madgwick, x-io Technologies).
class MadgwickAHRS {
public:
  void reset(); // quaternione identita'

  // Allinea l'asse Z del body frame alla gravita' misurata a riposo.
  // Da chiamare una volta in fase di calibrazione (dispositivo fermo).
  void alignToGravity(float ax, float ay, float az);

  void update(float gx, float gy, float gz,
              float ax, float ay, float az,
              float dt, float beta);

  float q0() const { return _q0; }
  float q1() const { return _q1; }
  float q2() const { return _q2; }
  float q3() const { return _q3; }

private:
  float _q0 = 1.0f, _q1 = 0.0f, _q2 = 0.0f, _q3 = 0.0f;
};

#endif
