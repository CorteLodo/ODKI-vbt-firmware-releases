#include "MotionTracker.h"
#include "MadgwickAHRS.h"
#include "LSM6DS3.h"
#include "Wire.h"

namespace {
  // ============================================================================
  // CONFIGURAZIONE - tutti i parametri temporali e le soglie tarabili del
  // modulo, raggruppati qui per poterli modificare in un unico punto senza
  // andare a caccia nell'implementazione sotto. Ogni valore resta comunque
  // usato/verificato vicino al proprio punto di impiego piu' avanti nel file.
  //
  // v3.0.0: SOLO fase concentrica. Una rep = una fase (velocita' positiva,
  // da PHASE_START_VELOCITY_MPS fino a tornare a zero o per piattezza).
  //
  // v3.1.0: direzione della fase tracciata configurabile a runtime (Up/Down,
  // vedi RuntimeConfig::repDirection in MotionTracker.h e repDirectionSign
  // sotto) - per esercizi dove conta la fase NEGATIVA (es. discesa
  // controllata) invece della positiva. Le soglie/durate che erano costanti
  // compilate in v3.0.0 (PHASE_START_VELOCITY_MPS, MIN/MAX_PHASE_DURATION_S,
  // FLAT_GUARD_MAX_VELOCITY_MPS, MAX_PLAUSIBLE_VELOCITY_MPS,
  // ZERO_CROSS_CONFIRM_SAMPLES) sono ora in RuntimeConfig, regolabili
  // dall'app via la Config characteristic (vedi BleServer.h) - i valori di
  // default restano gli stessi di prima.
  //
  // v3.2.0: DUE piste verticali separate, invece di una sola pista con due
  // significati sovrapposti come nelle versioni precedenti - trueVelZ (pista
  // "fisica", integra worldAccZ SEMPRE per l'INTERO movimento, tracciata e
  // ritorno) e refVelZ (pista "riportata", valida solo mentre una fase
  // concentrica e' aperta). Sostituisce il vecchio filtro anti-rimbalzo a
  // tempo fisso (debounceDurationS, rimosso) con un'attesa che dura
  // ESATTAMENTE quanto dura il ritorno vero invece di una stima temporale
  // fissa: dopo la chiusura di una fase valida, returnPhaseOpen resta vero
  // (vedi closePhase()) finche' il movimento OPPOSTO di trueVelZ non si
  // conclude per piattezza, con un timeout di sicurezza
  // (RuntimeConfig::returnPhaseTimeoutS) per non restare bloccati
  // indefinitamente se l'atleta non fa mai una vera pausa tra una rep e
  // l'altra (rep in continuo/touch-and-go): in quel caso, se trueVelZ
  // ri-supera la soglia di apertura fase PRIMA che il ritorno si sia concluso
  // da solo, l'attesa viene considerata implicitamente finita e la nuova fase
  // apre comunque (vedi il ramo "touch-and-go" in integrateMotion()).
  //
  // v3.5.0: formalizza/rende simmetriche le due piste, con ruoli distinti e
  // volutamente diversi (non solo per COME si azzerano, ma per QUANDO):
  //   - trueVelZ: con segno vero (positiva=su, negativa=giu'), mai floor
  //     per-campione durante l'integrazione (vedi bug storico sotto). Non sa
  //     nulla di rep/fasi e si azzera SOLO quando il Guard di piattezza (o un
  //     timeout di sicurezza) confermano che ci si puo' ragionevolmente
  //     fidare che il bilanciere sia davvero fermo - MAI per il solo
  //     passaggio a zero/sotto zero della velocita' direzionata (ZeroCross):
  //     continua per la sua strada, senza interruzioni, anche mentre una
  //     fase si chiude e inizia il ritorno.
  //   - refVelZ (variabile di stato esplicita, rispecchiata 1:1 in
  //     sample.refVelZ da MotionTracker::update(), quindi anche nel grafico
  //     live dell'app): all'apertura di ogni fase concentrica parte a ZERO
  //     (trueVelZ*repDirectionSign - phaseStartVelZ, vedi openPhase()), poi
  //     la segue campione per campione SOLO mentre la fase resta aperta
  //     (phaseOpen) - aggiornata ogni campione in integrateMotion(), non
  //     piu' ricalcolata al momento del report. RIBASATA su phaseStartVelZ
  //     esattamente come phasePeakVelocity/phaseVelocitySum in
  //     accumulateIntoPhase(): per un'apertura normale phaseStartVelZ e' 0,
  //     nessuna differenza pratica; per un'apertura touch-and-go pero' e'
  //     essenziale che refVelZ misuri lo STESSO contributo NETTO di questa
  //     fase riportato a chiusura - altrimenti il grafico live mostrerebbe
  //     un picco diverso da quello nel riepilogo della rep (bug reale,
  //     segnalato su hardware). Si azzera - e resta a zero - non appena la
  //     fase si chiude, sia per piattezza (soglie dinamiche sul proprio
  //     picco, phasePeakVelocity) sia per passaggio a zero/sotto zero
  //     (ZeroCross, qui scatta il conteggio della rep): a differenza di
  //     trueVelZ, non riparte mai a inseguire il ritorno.
  //   - Guard di piattezza di trueVelZ durante l'attesa del ritorno: a
  //     differenza della fase concentrica (dove la finestra si restringe
  //     dinamicamente sul proprio picco, phasePeakVelocity, per reagire in
  //     fretta anche su rep lente), durante returnPhaseOpen la finestra resta
  //     FISSA per l'intera durata dell'attesa, a RuntimeConfig::
  //     returnFlatWindowS (regolabile a runtime via BLE, default 0.30s -
  //     vedi returnFlatWindowSamples() sotto): qui non c'e' nessun picco di
  //     rep vera da proteggere da un falso positivo, quindi conviene solo
  //     essere il piu' possibile certi che il bilanciere si sia davvero
  //     fermato prima di azzerare trueVelZ.
  //
  // v3.8.0: due correzioni indipendenti, osservate su hardware:
  //   - quality1 sempre a 0 sulle fasi chiuse per piattezza (es. lo squat, che
  //     chiude cosi' al lockout): closePhase() leggeva refPosZ LIVE per
  //     calcolare displacementM, ma refPosZ e' gia' stata azzerata dal Guard
  //     di piattezza nello STESSO campione (velocita' direzionata forzata a 0
  //     -> non-positiva -> refPosZ si azzera in integrateMotion(), PRIMA che
  //     closePhase() venga chiamata) - displacementM finiva quindi sempre
  //     vicino a 0, quality1 sempre vicino a 0. Fix: nuovo flatStreakStartPosZ,
  //     posizione all'INIZIO (retroattivo) dello streak di piattezza, tracciata
  //     con lo stesso meccanismo di seeding gia' usato per
  //     flatStreakVelocitySum/flatStreakAccelSum - closePhase() la usa ora per
  //     il ramo Flat, simmetrico a come ZeroCross gia' usa
  //     phaseLastPositivePosZ invece del valore live.
  //   - accZBias (RuntimeConfig::accZBiasIdleStillTimeS): la stima del bias si
  //     aggiornava solo dopo 0.12s CONSECUTIVI di quiete confermata, sempre -
  //     in una serie di rep veloci/ravvicinate (poco riposo tra una rep e
  //     l'altra) il sensore puo' non stare mai fermo cosi' a lungo, quindi il
  //     bias resta congelato per l'intera serie: ogni residuo si integra nella
  //     velocita' per tutta la durata di ogni rep, con letture di picco
  //     incoerenti da una rep all'altra (sintomo osservato: spariva dopo una
  //     pausa lunga, l'unica finestra abbastanza lunga da soddisfare i 0.12s).
  //     Fix: fuori dalla fase concentrica tracciata (phaseOpen false, quindi
  //     durante il ritorno o l'idle) basta una quiete piu' breve e configurabile
  //     per aggiornare sia accZBias sia il bias del giroscopio - durante la
  //     fase resta il tempo fisso e prudente di prima.
  //
  // v3.9.0: RuntimeConfig::debugLogEnabled - log dati grezzi su Serial per
  // analisi di laboratorio, OFF di default. Sostituisce i vecchi messaggi di
  // testo libero sparsi nei guard (urto/clamp/piattezza forzata/ritorno
  // concluso/touch-and-go, RIMOSSI) con un log CSV omogeneo, una riga per
  // campione a 100Hz (tipo "S", vedi logSampleCsv()) piu' una riga per ogni
  // fine fase (tipo "R", vedi closePhase()) - la stessa informazione dei
  // vecchi messaggi e' ora nelle colonne shock/clamp/flat/touchAndGo di OGNI
  // campione (non solo sul fronte dell'evento) e nella colonna state (idle/
  // phase/return). Un log CSV senza testo libero intercalato e' quello che
  // serve per un parsing automatico affidabile - e riduce anche il volume
  // di Serial.print rispetto a prima (nessuna label testuale ripetuta).
  // Mentre e' attivo, lo streaming BLE decimato a 20Hz viene disattivato
  // (vedi loop() in VBT_Quaternions.ino): ridondante col log seriale, gia'
  // a 100Hz, e la sua notify() competerebbe per lo stesso ciclo di loop()
  // proprio mentre si cerca la cattura piu' pulita possibile.
  // ============================================================================

  // --- Campionamento / orientamento (Madgwick) ---
  const unsigned long SAMPLE_INTERVAL_MS = 1000UL / 100; // 100Hz
  const float BETA_BASE = 0.1f;
  // Guadagno adattivo Madgwick: trust scende quando l'accelerazione si
  // allontana da g (probabile moto vero), per non "correggere"
  // l'orientamento con letture accelerometriche contaminate dal
  // movimento. TRUST_FLOOR>0 mantiene sempre una correzione minima
  // (altrimenti, durante un moto esplosivo prolungato, l'orientamento
  // si affiderebbe solo al giroscopio e la sua deriva si accumulerebbe
  // senza correzione).
  const float TRUST_FLOOR = 0.15f;
  const float TRUST_FALLOFF = 5.0f;

  // --- Filtro mediano anti-shock sull'accelerometro grezzo (vedi MedianFilter3) ---
  const uint8_t MEDIAN_FILTER_SIZE = 5;

  // --- Bias residuo di worldAccZ, stima continua (vedi commento su accZBias) ---
  const float ACCZ_BIAS_TAU_S = 2.0f;              // costante di tempo della stima (lenta)
  const float ACCZ_BIAS_GYRO_MAX = 12.0f;          // deg/s: sopra questo il campione non e' quasi-statico
  const float ACCZ_BIAS_ACCMAG_TOLERANCE = 0.6f;   // m/s^2: scarto max di |accelerometro grezzo| da G
  const float ACCZ_BIAS_GYRO_STILL_TIME = 0.12f;   // secondi di quiete CONSECUTIVA richiesti (gyro E accMag)
  const float ACCZ_BIAS_MAX_STEP = 1.5f;           // m/s^2: scarto oltre il quale e' moto vero, non bias

  // --- Bias del giroscopio, stima CONTINUA (vedi commento su gyroBiasX/Y/Z) ---
  // Stessa idea/stessa finestra di quiete di accZBias sopra (quietForBias/
  // accZBiasStillDuration, riusate qui senza duplicarle - vedi
  // updateOrientationAndAcceleration()), ma con una costante di tempo molto
  // piu' lenta: il bias del giroscopio calibrato una volta sola in
  // calibrateOrientation() puo' spostarsi durante la sessione (tipicamente
  // per autoriscaldamento del chip), e un bias non aggiornato fa ruotare
  // lentamente l'orientamento stimato ("su" vero) - la causa piu' probabile
  // della lenta deriva di accZBias osservata su sessioni lunghe (vedi
  // analisi dei log). GYRO_BIAS_TAU_S deliberatamente piu' lento di
  // ACCZ_BIAS_TAU_S: qui l'obiettivo e' inseguire una deriva termica lenta,
  // non reagire in fretta - una costante di tempo corta rischierebbe di
  // "correggere via" un vero, piccolo movimento sostenuto scambiandolo per
  // bias.
  const float GYRO_BIAS_TAU_S = 8.0f;

  // --- Leak "cosmetico" SOLO su worldVelX/Y (nessun ruolo in fasi/rep) ---
  // A differenza della vecchia v2, l'asse Z (trueVelZ) NON ha piu' leak: si
  // azzera da solo ad ogni rep (vedi sopra), quindi il problema che il leak
  // doveva risolvere (deriva su lunghe sequenze senza mai un vero stop) non
  // si presenta piu'. X/Y restano pero' senza nessun meccanismo di reset
  // (non decidono mai apertura/chiusura fase, solo streaming/debug): senza
  // un leak andrebbero alla deriva senza limite per l'intera sessione -
  // valore puramente cosmetico, non influisce su nessun dato riportato.
  const float VELOCITY_LEAK_XY_TAU_S = 1.8f;

  // --- Guard sulla velocita' stimata (trueVelZ) ---
  // 1) MAX_PLAUSIBLE_VELOCITY_MPS: nessun esercizio di palestra genera
  //    velocita' oltre questo limite fisico plausibile - un valore piu'
  //    alto/basso e' sicuramente deriva, si limita (clamp) su ENTRAMBI i
  //    lati: trueVelZ e' VERA (con segno, negativa durante l'eccentrica tra
  //    una rep e l'altra, vedi dichiarazione sotto), non solo positiva.
  // 2) Due finestre a scorrimento, con criteri DIVERSI, devono essere
  //    entrambe "piatte" insieme perche' scatti il Guard di piattezza (vedi
  //    VelocityFlatWindow/AccelFlatWindow sotto):
  //    - trueVelZ (direzionata): l'ESCURSIONE (max-min) negli ultimi N
  //      campioni resta entro un intervallo di ampiezza 2*VELOCITY_FLAT_BAND_MPS.
  //    - worldAccZ: TUTTI gli ultimi M campioni restano dentro
  //      +-ACCELERATION_FLAT_BAND_MPS da ZERO (vicinanza ASSOLUTA).
  //    Se entrambe le condizioni sono vere, non c'e' moto vero (un rep vero
  //    ha sempre un profilo di accelerazione) - si azzera trueVelZ. Usato per
  //    TRE scopi diversi a seconda dello stato (vedi integrateMotion()):
  //    chiudere una fase concentrica bloccata a meta' (mai tornata a zero),
  //    concludere l'attesa del ritorno (returnPhaseOpen), o semplicemente
  //    ripulire un residuo quando non c'e' ne' l'uno ne' l'altro. NESSUN
  //    tetto assoluto di velocita' blocca piu' questa chiusura (rimosso -
  //    vedi nota storica sotto): se il segnale resta DAVVERO piatto
  //    abbastanza a lungo, si chiude qualunque sia il valore assoluto.
  //    N e M (currentVelWindowSamples/currentAccWindowSamples) si riducono
  //    linearmente SOLO mentre una fase concentrica e' aperta, al crescere
  //    della velocita' di picco della fase in corso (phasePeakVelocity) -
  //    vedi computeDynamicWindowSamples() sotto - con un minimo di
  //    RuntimeConfig::inPhaseMinFlatWindowS (piu' alto del minimo assoluto
  //    usato in idle), apposta per non scambiare il picco naturale di una rep
  //    veloce - dove l'accelerazione passa per zero e la velocita' e' quasi
  //    costante per un istante, esattamente come un plateau vero - per un
  //    blocco. Fuori da una fase aperta la finestra e' invece FISSA: al
  //    MASSIMO per tutta l'attesa del ritorno (returnPhaseOpen - qui non
  //    c'e' nessun picco di rep da proteggere, solo la certezza che il
  //    bilanciere si sia fermato, vedi nota di v3.5.0 in cima al file), al
  //    MINIMO in idle vero (nessuna rep in corso, reazione piu' veloce
  //    possibile).
  // (valore di default in RuntimeConfig::maxPlausibleVelocityMps,
  // MotionTracker.h - regolabile a runtime via BLE, vedi activeConfig sotto)
  //
  // STORIA: fino a v3.2.0 esisteva anche RuntimeConfig::flatGuardMaxVelocityMps,
  // un tetto assoluto oltre il quale il Guard di piattezza non poteva MAI
  // chiudere una fase aperta, indipendentemente da quanto le due finestre
  // sopra risultassero piatte - pensato per proteggere lo stesso picco di
  // rep veloce descritto sopra. Rimosso perche' con la finestra MAI sotto
  // RuntimeConfig::inPhaseMinFlatWindowS la stessa protezione e' gia' garantita
  // (un vero picco di rep non resta piatto cosi' a lungo), e senza tetto
  // una fase rimasta bloccata ad alta velocita' (es. per un residuo
  // ereditato da un'apertura touch-and-go, vedi integrateMotion()) si
  // risolve in una manciata di campioni invece di dover aspettare
  // MAX_PHASE_DURATION_S.

  // Capacita' REALE dei buffer circolari (VelocityFlatWindow/AccelFlatWindow/
  // AccelHistoryBuffer sotto) - un tetto puramente tecnico/di memoria,
  // volutamente piu' alto di qualunque finestra effettivamente richiesta
  // (vedi RuntimeConfig::returnFlatWindowS, il valore configurabile con il
  // range piu' ampio che usa questi buffer) cosi' da lasciare margine senza
  // dover ritoccare la dimensione degli array. NON e' lo stesso concetto di
  // MAX_VELOCITY/ACCELERATION_FLAT_WINDOW_SAMPLES sotto (quello e' il
  // tetto della finestra dinamica IN FASE, un valore di prodotto/algoritmo,
  // non di memoria) - tenerli separati evita che alzare l'uno alzi anche
  // l'altro per accidente. Deve restare <=255: nextIdx/count/windowSamples
  // in tutto il resto del file sono uint8_t.
  const uint8_t FLAT_WINDOW_BUFFER_CAPACITY = 150; // 1.5s a 100Hz

  const float VELOCITY_FLAT_BAND_MPS = 0.04f;
  // Tetto della finestra DINAMICA usata SOLO mentre una fase concentrica e'
  // aperta (vedi accumulateIntoPhase()/computeDynamicWindowSamples()) - non
  // regolabile a runtime, a differenza del tetto usato per l'attesa del
  // ritorno (RuntimeConfig::returnFlatWindowS, vedi sotto): la finestra in
  // fase serve solo a reagire in fretta a un blocco, non a "essere sicuri"
  // di qualcosa, quindi non ha bisogno della stessa flessibilita'.
  const uint8_t MAX_VELOCITY_FLAT_WINDOW_SAMPLES = 30;
  const uint8_t MIN_VELOCITY_FLAT_WINDOW_SAMPLES = 2;

  const float ACCELERATION_FLAT_BAND_MPS = 0.3f;
  const uint8_t MAX_ACCELERATION_FLAT_WINDOW_SAMPLES = 30;
  const uint8_t MIN_ACCELERATION_FLAT_WINDOW_SAMPLES = 2;
  // Minimo a cui le finestre possono arrivare SOLO mentre una fase
  // concentrica e' aperta (vedi accumulateIntoPhase()) - piu' alto del
  // minimo assoluto (MIN_VELOCITY/ACCELERATION_FLAT_WINDOW_SAMPLES, usato
  // invece per il ritorno/idle, dove non c'e' nessun picco di rep da
  // proteggere). Default ~200ms a 100Hz: abbastanza breve da risolvere un
  // blocco molto piu' in fretta del timeout assoluto, abbastanza lungo da
  // non scambiare il picco naturale di una rep veloce (dove l'accelerazione
  // passa per zero per un istante) per un plateau vero. Regolabile a
  // runtime via BLE (vedi RuntimeConfig::inPhaseMinFlatWindowS,
  // MotionTracker.h, e inPhaseMinFlatWindowSamples() sotto) per chi ha
  // bisogno di piu' pazienza (pause volontarie a meta' fase).
  // Velocita' di picco (m/s) oltre la quale la finestra e' gia' al minimo -
  // vedi computeDynamicWindowSamples().
  // Quanti campioni CONSECUTIVI il filtro anti-shock (vedi integrateMotion())
  // puo' scartare prima di doversi arrendere e accettare comunque il
  // campione corrente. Un urto vero dura tipicamente 2-4 campioni (verificato
  // su un urto reale catturato in log): oltre questo, un salto che PERSISTE
  // non e' piu' un urto - e' un cambio vero e sostenuto (es. la decelerazione
  // a fine spinta) che il filtro starebbe altrimenti rifiutando all'infinito,
  // confrontando ogni nuovo campione contro un riferimento ormai congelato e
  // superato (bug osservato su hardware: trueVelZ saliva senza fermarsi mai
  // fino al tetto di maxPlausibleVelocityMps).
  const uint8_t SHOCK_MAX_CONSECUTIVE_REJECT_SAMPLES = 4;
  const float WINDOW_SAMPLE_SATURATION_PEAK_VELOCITY = 0.8f;

  // --- Identificazione fase/rep (SOLO concentrica) ---
  // Una fase inizia quando trueVelZ*repDirectionSign supera
  // PHASE_START_VELOCITY_MPS (soglia POSITIVA: sotto questa soglia, o
  // negativa, non c'e' fase) e finisce in uno di tre modi (vedi
  // PhaseCloseReason sotto):
  //   - ZeroCross: trueVelZ VERA (con segno, vedi sotto) scende a/sotto zero
  //     per ZERO_CROSS_CONFIRM_SAMPLES campioni consecutivi - fine naturale
  //     del movimento concentrico (la persona ha smesso di spingere/sta
  //     decelerando fino a fermarsi, indipendentemente da quando
  //     l'ACCELERAZIONE torna positiva: durante la decelerazione a fine
  //     fase l'accelerazione e' gia' positiva mentre la velocita' e' ancora
  //     positiva ma calante - non e' un nuovo movimento).
  //   - Flat: il Guard di piattezza combinato (vedi sopra) rileva un
  //     plateau senza mai tornare a zero (rep bloccata a meta').
  //   - Timeout: rete di sicurezza indipendente, vedi MAX_PHASE_DURATION_S.
  // Una fase piu' corta di MIN_PHASE_DURATION_S e' scartata (probabile
  // rimbalzo/rumore, non un vero rep).
  // (valori di default in RuntimeConfig::phaseStartVelocityMps/
  // minPhaseDurationS/maxPhaseDurationS, MotionTracker.h)
  // Quando trueVelZ supera la soglia di inizio fase, gli ultimi
  // PHASE_LOOKBACK_SAMPLES campioni PRECEDENTI vengono ripescati dalla
  // storia se erano gia' positivi (movimento gia' iniziato, solo sotto
  // soglia) - cosi' la fase non perde la rampa iniziale.
  const uint8_t PHASE_LOOKBACK_SAMPLES = 5;

  // Chiude la fase quando trueVelZ VERA (con segno) resta a/sotto zero per
  // questi campioni CONSECUTIVI - non un singolo campione rumoroso vicino
  // allo zero (vedi analisi squatIre_*: serve una piccola conferma,
  // altrimenti un rimbalzo isolato chiuderebbe rep vere in anticipo).
  // (valore di default in RuntimeConfig::zeroCrossConfirmSamples)

  // --- Calibrazione orientamento (comando CALIBRATE, vedi calibrateOrientation()) ---
  const uint16_t CALIBRATION_SAMPLES = 200;
  const uint8_t CALIBRATION_SAMPLE_DELAY_MS = 10; // durata totale = CALIBRATION_SAMPLES * questo (2s di default)
  // Soglia empirica: un giroscopio davvero fermo oscilla di pochi decimi di
  // grado/s durante la finestra di calibrazione. 3 deg/s di range e' gia'
  // un margine largo per il rumore normale, ma abbastanza stretto da
  // segnalare un vero movimento residuo (bias stimato probabilmente sporco).
  const float CALIBRATION_GYRO_RANGE_WARN_DEG_S = 3.0f;
  // Rigetto outlier per singolo campione durante CALIBRATE: osservato su
  // hardware che anche col percorso di lettura robusto (poll()/harvest()
  // gated su STATUS_REG, vedi sotto) restano occasionali campioni anomali
  // di 4-6 deg/s - un ordine di grandezza sopra il rumore tipico da fermo
  // (<0.2 deg/s) ma troppo diluiti dalla media di harvest() per essere un
  // vero movimento sostenuto (probabile collisione I2C/radio BLE, non
  // rumore fisico). Soglia ben sopra il rumore normale, ben sotto qualunque
  // vero movimento.
  const float CALIBRATION_OUTLIER_REJECT_DEG_S = 1.0f;
  const uint8_t CALIBRATION_OUTLIER_MAX_RETRIES = 5; // rete di sicurezza: se il dispositivo si muove DAVVERO, non ricampionare all'infinito

  const float G = 9.80665f; // accelerazione di gravita' standard, m/s^2 - non tarabile

  // Riduzione LINEARE della dimensione di una finestra di piattezza in base
  // alla velocita' di picco della fase in corso - vedi accumulateIntoPhase().
  uint8_t computeDynamicWindowSamples(float peakVelocity, uint8_t minSamples, uint8_t maxSamples) {
    if (peakVelocity <= 0.0f) return maxSamples;
    if (peakVelocity >= WINDOW_SAMPLE_SATURATION_PEAK_VELOCITY) return minSamples;
    float fraction = peakVelocity / WINDOW_SAMPLE_SATURATION_PEAK_VELOCITY; // 0..1
    float value = (float)maxSamples - fraction * (float)(maxSamples - minSamples);
    uint8_t result = (uint8_t)(value + 0.5f);
    if (result < minSamples) result = minSamples;
    if (result > maxSamples) result = maxSamples;
    return result;
  }

  LSM6DS3 imu(I2C_MODE, 0x6A);
  MadgwickAHRS ahrs;

  // Il buffer e' dimensionato alla capacita' REALE (FLAT_WINDOW_BUFFER_
  // CAPACITY, vedi sopra), ma isFlat() valuta solo gli ultimi `windowSamples`
  // campioni passati come parametro (<=capacita', dimensionato in fase da
  // computeDynamicWindowSamples() o fisso da RuntimeConfig::
  // returnFlatWindowS durante l'attesa del ritorno, vedi currentVelWindowSamples).
  struct VelocityFlatWindow {
    float buf[FLAT_WINDOW_BUFFER_CAPACITY] = {0};
    uint8_t nextIdx = 0;
    uint8_t count = 0;

    void push(float v) {
      buf[nextIdx] = v;
      nextIdx = (nextIdx + 1) % FLAT_WINDOW_BUFFER_CAPACITY;
      if (count < FLAT_WINDOW_BUFFER_CAPACITY) count++;
    }

    // Indice del campione `i` (0=piu' vecchio) tra gli ultimi `windowSamples` bufferizzati.
    uint8_t indexOfLastWindow(uint8_t windowSamples, uint8_t i) const {
      return (uint8_t)((nextIdx + FLAT_WINDOW_BUFFER_CAPACITY - windowSamples + i) % FLAT_WINDOW_BUFFER_CAPACITY);
    }

    // true se gli ultimi `windowSamples` campioni (<=count) sono tutti
    // rientrati in una banda di ampiezza 2*VELOCITY_FLAT_BAND_MPS
    // (escursione max-min della finestra, non vicinanza assoluta a zero).
    bool isFlat(uint8_t windowSamples) const {
      if (windowSamples == 0 || count < windowSamples) return false;
      float lo = buf[indexOfLastWindow(windowSamples, 0)];
      float hi = lo;
      for (uint8_t i = 1; i < windowSamples; i++) {
        float v = buf[indexOfLastWindow(windowSamples, i)];
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
      return (hi - lo) <= (2.0f * VELOCITY_FLAT_BAND_MPS);
    }

    void reset() { nextIdx = 0; count = 0; }
  };
  VelocityFlatWindow velZFlatWindow;

  // Finestra su worldAccZ (valore CON SEGNO): la finestra e' indipendente
  // (dimensione/banda propri, MAX/MIN_ACCELERATION_FLAT_WINDOW_SAMPLES/
  // ACCELERATION_FLAT_BAND_MPS) e concorre alla decisione di chiusura
  // insieme a velZFlatWindow.isFlat() (vedi integrateMotion()). Serve anche
  // a escludere la coda piatta dalla media di una fase quando il guard
  // scatta, vedi closePhase(). A DIFFERENZA di VelocityFlatWindow: qui il
  // criterio NON e' l'escursione relativa della finestra, ma la vicinanza
  // ASSOLUTA a zero di OGNI campione.
  struct AccelFlatWindow {
    float buf[FLAT_WINDOW_BUFFER_CAPACITY] = {0};
    uint8_t nextIdx = 0;
    uint8_t count = 0;

    void push(float v) {
      buf[nextIdx] = v;
      nextIdx = (nextIdx + 1) % FLAT_WINDOW_BUFFER_CAPACITY;
      if (count < FLAT_WINDOW_BUFFER_CAPACITY) count++;
    }

    uint8_t indexOfLastWindow(uint8_t windowSamples, uint8_t i) const {
      return (uint8_t)((nextIdx + FLAT_WINDOW_BUFFER_CAPACITY - windowSamples + i) % FLAT_WINDOW_BUFFER_CAPACITY);
    }

    // true se gli ultimi `windowSamples` campioni (<=count) sono TUTTI
    // rimasti dentro +-ACCELERATION_FLAT_BAND_MPS da ZERO.
    bool isFlat(uint8_t windowSamples) const {
      if (windowSamples == 0 || count < windowSamples) return false;
      for (uint8_t i = 0; i < windowSamples; i++) {
        if (fabs(buf[indexOfLastWindow(windowSamples, i)]) > ACCELERATION_FLAT_BAND_MPS) return false;
      }
      return true;
    }

    void reset() { nextIdx = 0; count = 0; }
  };
  AccelFlatWindow accZWindow;

  // --- Tracciamento dinamico della "coda piatta" da escludere dalla media ---
  // accZWindow (sopra) e' dimensionata per la DECISIONE di piattezza
  // dell'accelerazione (dimensione dinamica <= MAX_ACCELERATION_FLAT_
  // WINDOW_SAMPLES, o fissa a RuntimeConfig::returnFlatWindowS durante
  // l'attesa del ritorno), ma quando il guard scatta la velocita' potrebbe
  // essere piatta (secondo velZFlatWindow) da MOLTI piu' campioni di quanti
  // l'accelerazione ne abbia impiegati a raggiungere la sua banda. Per
  // poter scartare dalla media TUTTO il periodo in cui la velocita' era
  // gia' piatta per conto suo, serve poter sommare |worldAccZ| su un
  // tratto piu' lungo dei soli campioni della finestra di accelerazione:
  // bufferizzato qui, con la capacita' REALE dei buffer (FLAT_WINDOW_
  // BUFFER_CAPACITY, stessa capacita' di velZFlatWindow).
  struct AccelHistoryBuffer {
    float buf[FLAT_WINDOW_BUFFER_CAPACITY] = {0};
    uint8_t nextIdx = 0;
    uint8_t count = 0;

    void push(float v) {
      buf[nextIdx] = v;
      nextIdx = (nextIdx + 1) % FLAT_WINDOW_BUFFER_CAPACITY;
      if (count < FLAT_WINDOW_BUFFER_CAPACITY) count++;
    }

    void reset() { nextIdx = 0; count = 0; }
  };
  AccelHistoryBuffer accHistoryForVelStreak;
  // Stesso buffer generico, riusato per refPosZ invece di |worldAccZ| -
  // serve a recuperare la posizione all'INIZIO (retroattivo) dello streak di
  // piattezza (vedi flatStreakStartPosZ sotto), con lo stesso meccanismo di
  // seeding gia' usato per flatStreakVelocitySum/flatStreakAccelSum. Pushato
  // con refPosZ COM'ERA alla fine del campione precedente (l'integrazione di
  // posizione di QUESTO campione avviene piu' avanti in integrateMotion()) -
  // sfasamento di un campione (~10ms) irrilevante su una finestra fino a
  // qualche centinaio di ms.
  AccelHistoryBuffer posHistoryForFlatStreak;

  // Contatore di quanti campioni CONSECUTIVI velZFlatWindow.isFlat() e'
  // rimasta vera, con le somme trueVelZ/|worldAccZ| corrispondenti gia'
  // pronte per l'esclusione in closePhase(). Alla PRIMA volta che isFlat()
  // torna vera parte gia' da currentVelWindowSamples (quei campioni erano
  // gia' tutti piatti) - non da 1 - "seminando" le somme dal buffer
  // velZFlatWindow/accHistoryForVelStreak gia' disponibili; poi cresce di 1
  // ad ogni campione successivo ancora piatto. Si azzera da solo (ramo else
  // sotto) appena velZFlatWindow torna non-piatta.
  uint16_t velFlatStreakSamples = 0;
  float flatStreakVelocitySum = 0;
  float flatStreakAccelSum = 0;
  // Tempo REALE coperto dallo stesso streak - sottratto da phaseElapsedS in
  // closePhase() cosi' la durata della fase si ferma all'INIZIO della coda
  // piatta invece che alla chiusura effettiva.
  float flatStreakElapsedS = 0;
  // Posizione (refPosZ) all'INIZIO dello stesso streak - usata da closePhase()
  // per il ramo Flat al posto di refPosZ live, per lo STESSO motivo per cui
  // phaseElapsedS viene ridotto sopra: refPosZ live e' gia' stata azzerata
  // dal Guard di piattezza nello stesso campione (trueVelZ->0 rende la
  // velocita' direzionata non-positiva, che azzera refPosZ in
  // integrateMotion() PRIMA che closePhase() venga chiamata) - usarla
  // direttamente riportava displacementM a ~0 per OGNI fase chiusa per
  // piattezza, quindi quality1 a 0 sempre (bug reale, osservato sullo squat).
  float flatStreakStartPosZ = 0;

  // Streak per la conferma di "trueVelZ VERA a/sotto zero" (vedi
  // ZERO_CROSS_CONFIRM_SAMPLES): conta i campioni CONSECUTIVI in cui trueVelZ
  // (con segno, vedi dichiarazione) e' <=0. Nessuna soglia di magnitudine
  // richiesta (a differenza del vecchio Reversal, che serviva a distinguere
  // una vera inversione da rumore in un mondo bidirezionale) - qui basta
  // che la velocita' sia scesa a/sotto zero, e' gia' di per se' la fine del
  // movimento concentrico.
  uint16_t zeroCrossStreakSamples = 0;

  // --- Filtro mediano sull'accelerometro grezzo (anti-shock meccanico) ---
  // Uno shock meccanico (es. urto del bilanciere a terra nel touch-and-go,
  // trasmesso dal supporto sul bilanciere) produce un picco isolato di
  // pochi campioni che il filtro adattivo sull'accelerazione lascerebbe
  // passare quasi indisturbato. Un filtro MEDIANO a MEDIAN_FILTER_SIZE
  // campioni (vedi CONFIGURAZIONE in cima al file), applicato prima di
  // tutto (trust Madgwick, update Madgwick, sottrazione gravita'),
  // sostituisce un singolo campione anomalo con i vicini mentre lascia
  // passare quasi intatta un'accelerazione vera che dura piu' campioni
  // consecutivi. Introduce un ritardo di (N-1)/2 campioni (20ms a N=5).
  struct MedianFilter3 {
    float bufX[MEDIAN_FILTER_SIZE] = {0};
    float bufY[MEDIAN_FILTER_SIZE] = {0};
    float bufZ[MEDIAN_FILTER_SIZE] = {0};
    uint8_t nextIdx = 0;
    bool primed = false;

    static float median(const float buf[MEDIAN_FILTER_SIZE]) {
      float tmp[MEDIAN_FILTER_SIZE];
      for (uint8_t i = 0; i < MEDIAN_FILTER_SIZE; i++) tmp[i] = buf[i];
      // Insertion sort: piu' economico di un sort generico per N cosi' piccolo.
      for (uint8_t i = 1; i < MEDIAN_FILTER_SIZE; i++) {
        float key = tmp[i];
        int8_t j = (int8_t)i - 1;
        while (j >= 0 && tmp[j] > key) { tmp[j + 1] = tmp[j]; j--; }
        tmp[j + 1] = key;
      }
      return tmp[MEDIAN_FILTER_SIZE / 2];
    }

    void filter(float x, float y, float z, float& outX, float& outY, float& outZ) {
      if (!primed) {
        // Precarica tutta la finestra col primo campione, altrimenti gli
        // zeri di inizializzazione del buffer sporcherebbero la mediana
        // durante il primo mezzo secondo di funzionamento.
        for (uint8_t i = 0; i < MEDIAN_FILTER_SIZE; i++) { bufX[i] = x; bufY[i] = y; bufZ[i] = z; }
        primed = true;
      }
      bufX[nextIdx] = x; bufY[nextIdx] = y; bufZ[nextIdx] = z;
      nextIdx = (nextIdx + 1) % MEDIAN_FILTER_SIZE;
      outX = median(bufX); outY = median(bufY); outZ = median(bufZ);
    }
  };
  MedianFilter3 accMedianFilter;
  // Stesso filtro, applicato al giroscopio - vedi commento in
  // updateOrientationAndAcceleration() sul perche' e' stato aggiunto (i
  // glitch I2C/radio osservati durante CALIBRATE, vedi CALIBRATION_
  // OUTLIER_REJECT_DEG_S, colpiscono lo stesso percorso di lettura anche a
  // runtime - qui pero' il giroscopio andava DIRETTO nell'aggiornamento
  // Madgwick, senza nessuna protezione, a differenza dell'accelerometro).
  MedianFilter3 gyroMedianFilter;

  // --- Accumulatore per media veloce accelerometro/giroscopio (anti-aliasing) ---
  // Il chip LSM6DS3 campiona internamente a 416Hz, ma l'elaborazione gira a
  // 100Hz: senza accumulo si scarterebbe in media ~3 campioni su 4. poll()
  // interroga STATUS_REG (bit XLDA/GDA = nuovo campione pronto) ad ogni
  // giro di loop() e accumula tutti i campioni realmente nuovi; harvest()
  // ne fa la media (valore corretto da dare all'integrazione trapezoidale)
  // e azzera l'accumulatore.
  struct FastSampleAccumulator {
    float sumAx = 0, sumAy = 0, sumAz = 0;
    uint32_t countA = 0;
    float sumGx = 0, sumGy = 0, sumGz = 0;
    uint32_t countG = 0;

    void poll() {
      uint8_t status = 0;
      if (imu.readRegister(&status, LSM6DS3_ACC_GYRO_STATUS_REG) != IMU_SUCCESS) return;
      if (status & 0x01) { // XLDA: nuovo campione accelerometro
        uint8_t buf[6];
        if (imu.readRegisterRegion(buf, LSM6DS3_ACC_GYRO_OUTX_L_XL, 6) == IMU_SUCCESS) {
          sumAx += imu.calcAccel((int16_t)(buf[0] | (buf[1] << 8)));
          sumAy += imu.calcAccel((int16_t)(buf[2] | (buf[3] << 8)));
          sumAz += imu.calcAccel((int16_t)(buf[4] | (buf[5] << 8)));
          countA++;
        }
      }
      if (status & 0x02) { // GDA: nuovo campione giroscopio
        uint8_t buf[6];
        if (imu.readRegisterRegion(buf, LSM6DS3_ACC_GYRO_OUTX_L_G, 6) == IMU_SUCCESS) {
          sumGx += imu.calcGyro((int16_t)(buf[0] | (buf[1] << 8)));
          sumGy += imu.calcGyro((int16_t)(buf[2] | (buf[3] << 8)));
          sumGz += imu.calcGyro((int16_t)(buf[4] | (buf[5] << 8)));
          countG++;
        }
      }
    }

    // Se non fosse arrivato nessun campione nuovo (non atteso a 416Hz su
    // una finestra di 10ms, ma in teoria possibile se loop() fosse
    // eccezionalmente lento) ripiega su una singola lettura diretta.
    void harvest(float& ax, float& ay, float& az, float& gx, float& gy, float& gz) {
      if (countA > 0) {
        ax = sumAx / countA; ay = sumAy / countA; az = sumAz / countA;
      } else {
        ax = imu.readFloatAccelX(); ay = imu.readFloatAccelY(); az = imu.readFloatAccelZ();
      }
      if (countG > 0) {
        gx = sumGx / countG; gy = sumGy / countG; gz = sumGz / countG;
      } else {
        gx = imu.readFloatGyroX(); gy = imu.readFloatGyroY(); gz = imu.readFloatGyroZ();
      }
      sumAx = sumAy = sumAz = 0; countA = 0;
      sumGx = sumGy = sumGz = 0; countG = 0;
    }
  };
  FastSampleAccumulator fastSamples;

  // --- Bias residuo di worldAccZ (stima continua, soglie in CONFIGURAZIONE) ---
  // Anche con orientamento ben calibrato resta un piccolo offset su
  // worldAccZ (residuo di allineamento gravita' + deriva lenta
  // dell'orientamento durante il moto), che altrimenti impedirebbe alla
  // velocita' di tornare a zero da ferma. Rimedio: stimare il bias in
  // continuo con un filtro molto lento, ma SOLO sui campioni quasi-statici
  // (giroscopio basso E accelerometro grezzo vicino a G) - durante il moto
  // vero la stima resta congelata.
  float accZBias = 0;
  float accZBiasStillDuration = 0; // tempo reale consecutivo di quiete (gyro basso E accMag~G)

  unsigned long lastSampleTime = 0;
  bool trackingActive = false;
  bool calibrated = false;
  MotionSample sample;

  float lastGyroMag = 0;

  // Bias del giroscopio (zero-rate offset), sottratto ad ogni lettura -
  // valore INIZIALE stimato in calibrateOrientation() tenendo il
  // dispositivo fermo, poi corretto in continuo con una stima lenta (vedi
  // GYRO_BIAS_TAU_S in updateOrientationAndAcceleration()) durante i
  // momenti di quiete confermata nel corso della sessione, per seguire
  // un'eventuale deriva termica invece di restare congelato al valore del
  // primo CALIBRATE.
  float gyroBiasX = 0, gyroBiasY = 0, gyroBiasZ = 0;

  // Scala reale g->m/s^2 di QUESTO specifico accelerometro, stimata in
  // calibrateOrientation() (dispositivo fermo, quindi il modulo misurato
  // DEVE essere G): sostituisce la costante ideale G in
  // updateOrientationAndAcceleration() per la conversione unita'/sottrazione
  // gravita'. Di default = G (costante ideale) finche' non arriva la prima
  // calibrazione.
  float accelScaleG = G;

  // --- Configurazione runtime (vedi RuntimeConfig in MotionTracker.h) ---
  // Valori di fabbrica: catturati UNA VOLTA in un oggetto separato (non
  // toccato da setConfig()) cosi' defaultConfig() puo' sempre restituirli,
  // anche dopo che activeConfig e' stata modificata via BLE. NON persistiti
  // in flash: ad ogni riavvio activeConfig riparte identica a
  // DEFAULT_CONFIG finche' l'app non invia una configurazione diversa.
  const RuntimeConfig DEFAULT_CONFIG;
  RuntimeConfig activeConfig;

  // +1 = Up (default, fase concentrica positiva), -1 = Down (fase
  // concentrica negativa) - derivato da activeConfig.repDirection ad ogni
  // setConfig(). Applicato come moltiplicatore su trueVelZ in OGNI punto in
  // cui il codice sotto decide "e' la direzione tracciata?" (soglie di
  // apertura/chiusura fase, guard di piattezza, esclusione dalla media,
  // valore riportato) - vedi i punti in cui compare
  // "* repDirectionSign" piu' avanti nel file. trueVelZ stessa resta SEMPRE
  // la velocita' fisica vera (positiva=su, negativa=giu'), indipendente
  // dalla direzione tracciata: e' solo l'INTERPRETAZIONE del suo segno a
  // dipendere da repDirectionSign, mai il suo valore.
  int8_t repDirectionSign = 1;

  // --- Attesa del ritorno (sostituisce il vecchio debounce a tempo fisso) ---
  // true dalla chiusura di una fase valida (vedi closePhase()) finche' il
  // movimento OPPOSTO di trueVelZ (il ritorno verso la posizione iniziale)
  // non si e' a sua volta concluso - per piattezza (stesso Guard di
  // piattezza della fase concentrica, ma senza il tetto assoluto: qui non
  // c'e' nessuna rep vera da proteggere, vedi il gating "!phaseOpen" in
  // integrateMotion()) o per timeout di sicurezza
  // (RuntimeConfig::returnPhaseTimeoutS, per non restare bloccati
  // indefinitamente su rep in continuo/touch-and-go). Mutuamente esclusivo
  // con phaseOpen: non sono mai veri insieme.
  bool  returnPhaseOpen = false;
  float returnPhaseElapsedS = 0;

  // X/Y: solo streaming/debug, nessun ruolo in fasi/rep - vedi
  // VELOCITY_LEAK_XY_TAU_S sopra.
  float worldVelX = 0, worldVelY = 0;
  float worldPosX = 0, worldPosY = 0;

  // Pista verticale VERA (vedi CONFIGURAZIONE in cima al file): con segno,
  // integra l'accelerazione in continuo, nessun floor per campione, per
  // l'INTERO movimento (sia la fase tracciata sia il ritorno). Durante
  // l'eccentrica (tra la fine di una rep e l'inizio della successiva) scende
  // regolarmente sotto zero, esattamente come una velocita' fisica vera:
  // azzerarla ad ogni singolo campione non-positivo (primo tentativo,
  // SBAGLIATO) confondeva "l'accelerazione e' tornata positiva" con "la
  // velocita' e' tornata positiva" - durante la decelerazione a fine discesa
  // l'accelerazione e' gia' positiva mentre la persona sta ancora scendendo
  // (velocita' ancora negativa), quindi ripartiva a crescere PRIMA del vero
  // punto di inversione (bug osservato su hardware). Si azzera invece SOLO
  // ai momenti di chiusura fase/attesa (Flat/Timeout/ZeroCross della fase
  // concentrica, o Flat/Timeout del ritorno, vedi closePhase() e
  // integrateMotion()) - abbastanza frequenti da non accumulare deriva
  // significativa nel frattempo, senza bisogno di nessun leak.
  float trueVelZ = 0, refPosZ = 0;

  // refVelZ (variabile di stato esplicita, vedi commento di v3.5.0 in cima
  // al file): (trueVelZ*repDirectionSign - phaseStartVelZ) troncata a zero
  // se negativa, ma valida/aggiornata SOLO mentre phaseOpen e' vero,
  // aggiornata ogni campione in fondo a integrateMotion() - la decisione
  // interna di apertura/chiusura fase/attesa lavora invece sempre su
  // trueVelZ, la velocita' VERA.
  float refVelZ = 0;

  // Integrazione trapezoidale: serve il campione precedente. trapezoidPrimed
  // = false al primo campione dopo un reset (Eulero semplice quella volta).
  bool  trapezoidPrimed = false;
  float prevWorldAccX = 0, prevWorldAccY = 0, prevWorldAccZ = 0;
  float prevWorldVelX = 0, prevWorldVelY = 0;
  float prevTrueVelZ = 0; // per l'integrazione trapezoidale di refPosZ

  // --- Identificazione fase/rep (soglie in CONFIGURAZIONE, in cima al file) ---
  // velZ e' gia' la velocita' DIREZIONATA (trueVelZ*repDirectionSign, vedi
  // pushHistory() in integrateMotion()), non trueVelZ grezza.
  struct HistorySample { float velZ = 0; float accZ = 0; float posZ = 0; float dt = 0; };
  HistorySample history[PHASE_LOOKBACK_SAMPLES];
  uint8_t historyNextIdx = 0;
  uint8_t historyCount = 0;

  void pushHistory(float velZ, float accZ, float posZ, float dt) {
    HistorySample& h = history[historyNextIdx];
    h.velZ = velZ; h.accZ = accZ; h.posZ = posZ; h.dt = dt;
    historyNextIdx = (historyNextIdx + 1) % PHASE_LOOKBACK_SAMPLES;
    if (historyCount < PHASE_LOOKBACK_SAMPLES) historyCount++;
  }

  // k=0 -> campione piu' recente (1 indietro rispetto al campione corrente,
  // non ancora pushato quando questa viene chiamata), k=1 -> 2 indietro, ecc.
  const HistorySample& historyAgo(uint8_t k) {
    uint8_t idx = (historyNextIdx + PHASE_LOOKBACK_SAMPLES - 1 - k) % PHASE_LOOKBACK_SAMPLES;
    return history[idx];
  }

  // Motivo di chiusura di una fase - vedi closePhase() per il trattamento
  // differenziato di media/durata per ciascuno.
  enum class PhaseCloseReason { Flat, Timeout, ZeroCross };

  bool    phaseOpen = false;
  float   phaseStartPosZ = 0; // refPosZ appena PRIMA del primo campione incluso nella fase
  // trueVelZ*repDirectionSign al momento dell'apertura (vedi openPhase()) -
  // per una fase normale e' ~0 (si apre da un ritorno gia' assestato), ma
  // per il ramo "touch-and-go" (vedi integrateMotion()) puo' essere
  // qualunque valore: sottratta in accumulateIntoPhase() cosi' picco/media
  // riportati misurano solo il contributo di QUESTA fase, non il residuo
  // ereditato dal ritorno precedente.
  float   phaseStartVelZ = 0;
  float   phaseElapsedS = 0;
  float   phaseVelocitySum = 0; int phaseVelocitySamples = 0;
  float   phaseAccelSum = 0; int phaseAccelSamples = 0;
  float   phasePeakVelocity = 0;
  float   phasePeakAcceleration = 0;
  // Istantanea di posizione/durata all'ULTIMO campione con traiettoria
  // grezza ANCORA positiva (aggiornata da accumulateIntoPhase()) - usata da
  // closePhase() per la chiusura ZeroCross al posto dei valori live al
  // momento della chiusura effettiva: refPosZ/phaseElapsedS continuano ad
  // avanzare (fermi, trueVelZ e' gia' 0) anche durante i campioni di
  // conferma, che non sono moto vero di questa fase.
  float   phaseLastPositivePosZ = 0;
  float   phaseLastPositiveElapsedS = 0;
  uint16_t phaseNonPositiveTotalSamples = 0;
  // true se durante la fase corrente trueVelZ e' stata limitata dal clamp al
  // massimo plausibile (vedi MAX_PLAUSIBLE_VELOCITY_MPS): usato per il
  // punteggio quality in closePhase().
  bool    phaseHadVelocityClamp = false;
  // Dimensione ATTUALE (<=MAX_*) delle due finestre di piattezza, CONDIVISA
  // tra tre stati mutuamente esclusivi (vedi integrateMotion()):
  //   - phaseOpen (fase concentrica): ricalcolata da
  //     computeDynamicWindowSamples() ad ogni nuovo picco di
  //     phasePeakVelocity (vedi accumulateIntoPhase()) - riparte da MAX ad
  //     ogni apertura (vedi openPhase()).
  //   - returnPhaseOpen (attesa del ritorno): FISSA a RuntimeConfig::
  //     returnFlatWindowS per l'intera durata dell'attesa, impostata una
  //     sola volta alla chiusura fase (vedi closePhase()) - qui non c'e'
  //     nessun picco di rep vera da proteggere, quindi si preferisce una
  //     finestra piu' lenta/prudente (vedi commento di v3.5.0 in cima al file).
  //   - ne' l'uno ne' l'altro (idle vero, incluso prima della primissima
  //     rep): fissa al MINIMO - qui non c'e' nessuna rep vera da proteggere
  //     da un falso positivo, quindi conviene confermare "piatto" il piu' in
  //     fretta possibile.
  uint8_t currentVelWindowSamples = MIN_VELOCITY_FLAT_WINDOW_SAMPLES;
  uint8_t currentAccWindowSamples = MIN_ACCELERATION_FLAT_WINDOW_SAMPLES;

  // Rep = UNA fase concentrica: avanza dopo OGNI fase valida completata.
  uint8_t currentRepNumber = 1;

  RepResult pendingRep;
  bool repPending = false;

  MotionDebugState debugStateVar;

  // Campioni CONSECUTIVI appena scartati dal filtro anti-shock - vedi
  // SHOCK_MAX_CONSECUTIVE_REJECT_SAMPLES e il suo uso in integrateMotion().
  uint8_t shockConsecutiveRejectSamples = 0;

  // Azzera l'integrazione di velocita'/posizione: chiamata all'avvio/stop
  // del tracciamento (vedi MotionTracker::setTrackingActive).
  void resetIntegration() {
    worldVelX = worldVelY = 0;
    worldPosX = worldPosY = 0;
    prevWorldVelX = prevWorldVelY = 0;
    trueVelZ = 0; refVelZ = 0; refPosZ = 0; prevTrueVelZ = 0;
    trapezoidPrimed = false;
    velZFlatWindow.reset();
    accZWindow.reset();
    accHistoryForVelStreak.reset();
    posHistoryForFlatStreak.reset();
    velFlatStreakSamples = 0;
    flatStreakVelocitySum = 0;
    flatStreakAccelSum = 0;
    flatStreakElapsedS = 0;
    flatStreakStartPosZ = 0;
    zeroCrossStreakSamples = 0;
    returnPhaseOpen = false;
    returnPhaseElapsedS = 0;
  }

  // Azzera lo stato di identificazione fase/rep: chiamata all'avvio/stop
  // del tracciamento, insieme a resetIntegration().
  void resetPhaseTracking() {
    phaseOpen = false;
    phaseStartPosZ = 0;
    phaseElapsedS = 0;
    phaseVelocitySum = 0; phaseVelocitySamples = 0;
    phaseAccelSum = 0; phaseAccelSamples = 0;
    phasePeakVelocity = 0;
    phasePeakAcceleration = 0;
    phaseHadVelocityClamp = false;
    currentVelWindowSamples = MIN_VELOCITY_FLAT_WINDOW_SAMPLES;
    currentAccWindowSamples = MIN_ACCELERATION_FLAT_WINDOW_SAMPLES;
    currentRepNumber = 1;
    repPending = false;
    historyNextIdx = 0;
    historyCount = 0;
  }

  // Legge IMU, aggiorna orientamento e accelerazione nel sistema del mondo.
  // Sempre eseguita (anche prima di START) cosi' l'orientamento resta fresco.
  void updateOrientationAndAcceleration(float dt) {
    float axAvg, ayAvg, azAvg, gxAvg, gyAvg, gzAvg;
    fastSamples.harvest(axAvg, ayAvg, azAvg, gxAvg, gyAvg, gzAvg);
    // accelScaleG (non G ideale): converte le unita' "g" grezze in m/s^2
    // usando la scala REALE di questo accelerometro (vedi commento sulla
    // dichiarazione) - un accelerometro con errore di scala/offset di
    // fabbrica altrimenti lascerebbe un residuo sistematico dopo la
    // sottrazione gravita' sotto, invece di leggere ~0 da fermo.
    float axRaw = axAvg * accelScaleG;
    float ayRaw = ayAvg * accelScaleG;
    float azRaw = azAvg * accelScaleG;
    // Filtro mediano anti-shock: applicato PRIMA di qualunque uso di
    // ax/ay/az, cosi' sia il trust di Madgwick sia l'update Madgwick
    // stesso sia il calcolo di worldAccZ vedono gia' il segnale ripulito.
    float ax, ay, az;
    accMedianFilter.filter(axRaw, ayRaw, azRaw, ax, ay, az);
    // Stessa protezione sul giroscopio, PRIMA della sottrazione del bias:
    // senza, un glitch isolato entrerebbe diretto nell'update di Madgwick,
    // perturbando l'orientamento stimato proprio mentre il guadagno
    // adattivo (TRUST_FLOOR/TRUST_FALLOFF) riduce la correzione via
    // accelerometro durante il moto esplosivo - meno autocorrezione
    // esattamente quando conta di piu'.
    float gxFiltered, gyFiltered, gzFiltered;
    gyroMedianFilter.filter(gxAvg, gyAvg, gzAvg, gxFiltered, gyFiltered, gzFiltered);
    // Bias sottratto in gradi/s, PRIMA della conversione a rad/s.
    float gx = (gxFiltered - gyroBiasX) * DEG_TO_RAD;
    float gy = (gyFiltered - gyroBiasY) * DEG_TO_RAD;
    float gz = (gzFiltered - gyroBiasZ) * DEG_TO_RAD;

    // Guadagno adattivo: meno correzione accelerometrica durante il moto esplosivo.
    float accMag = sqrt(ax * ax + ay * ay + az * az);
    float trust = constrain(1.0f - fabs(accMag - G) / G * TRUST_FALLOFF, TRUST_FLOOR, 1.0f);
    ahrs.update(gx, gy, gz, ax, ay, az, dt, BETA_BASE * trust);

    float q0 = ahrs.q0(), q1 = ahrs.q1(), q2 = ahrs.q2(), q3 = ahrs.q3();

    // Direzione della gravita' nel body frame (3a riga della matrice body->mondo)
    float gravBodyX = 2.0f * (q1 * q3 - q0 * q2);
    float gravBodyY = 2.0f * (q0 * q1 + q2 * q3);
    float gravBodyZ = q0 * q0 - q1 * q1 - q2 * q2 + q3 * q3;

    // Stessa scala reale (non G ideale) qui: gravBody* e' un versore
    // (direzione, adimensionale), il suo modulo dev'essere quello che
    // QUESTO sensore leggerebbe per la sola gravita' - coerente con
    // ax/ay/az sopra, gia' convertiti con accelScaleG.
    float linAccX = ax - gravBodyX * accelScaleG;
    float linAccY = ay - gravBodyY * accelScaleG;
    float linAccZ = az - gravBodyZ * accelScaleG;

    // Matrice body->mondo (righe 1-2; la 3a coincide con gravBody)
    float R00 = 1.0f - 2.0f * (q2 * q2 + q3 * q3);
    float R01 = 2.0f * (q1 * q2 - q0 * q3);
    float R02 = 2.0f * (q1 * q3 + q0 * q2);
    float R10 = 2.0f * (q1 * q2 + q0 * q3);
    float R11 = 1.0f - 2.0f * (q1 * q1 + q3 * q3);
    float R12 = 2.0f * (q2 * q3 - q0 * q1);

    // worldAccZ - solo questo asse, e' quello usato per la velocita' verticale.
    float worldAccZraw = linAccX * gravBodyX + linAccY * gravBodyY + linAccZ * gravBodyZ;

    // Aggiornamento della stima del bias PRIMA di sottrarlo: solo su
    // campioni quasi-statici (giroscopio basso E accelerometro grezzo
    // vicino a G), richiesto SOSTENUTO (non un singolo campione).
    bool quietForBias = (lastGyroMag < ACCZ_BIAS_GYRO_MAX) &&
                         (fabs(accMag - G) < ACCZ_BIAS_ACCMAG_TOLERANCE);
    accZBiasStillDuration = quietForBias ? (accZBiasStillDuration + dt) : 0.0f;
    // Fuori dalla fase concentrica tracciata (fase chiusa: attesa del
    // ritorno o idle vero) basta una quiete piu' breve per aggiornare il
    // bias - vedi RuntimeConfig::accZBiasIdleStillTimeS. Durante la fase
    // resta il tempo fisso e piu' prudente (ACCZ_BIAS_GYRO_STILL_TIME): un
    // plateau di velocita' a meta' rep non e' un buon momento per fidarsi
    // del bias, c'e' ancora spinta muscolare reale in corso. phaseOpen qui
    // riflette lo stato di fine campione PRECEDENTE (integrateMotion(), che
    // lo aggiorna, gira DOPO questa funzione nello stesso ciclo) - scarto di
    // un campione (~10ms) irrilevante per una soglia dell'ordine dei 50-120ms.
    float requiredStillTime = phaseOpen ? ACCZ_BIAS_GYRO_STILL_TIME : activeConfig.accZBiasIdleStillTimeS;
    if (accZBiasStillDuration >= requiredStillTime &&
        fabs(worldAccZraw - accZBias) < ACCZ_BIAS_MAX_STEP) {
      float alpha = dt / (ACCZ_BIAS_TAU_S + dt);
      accZBias += alpha * (worldAccZraw - accZBias);
    }

    // Aggiornamento CONTINUO del bias del giroscopio (vedi commento sulla
    // dichiarazione di GYRO_BIAS_TAU_S) - stessa finestra di quiete di
    // sopra (quietForBias/accZBiasStillDuration/requiredStillTime, non
    // duplicata), ma verso gxFiltered/gyFiltered/gzFiltered (il valore
    // grezzo PRIMA della sottrazione bias, non gx/gy/gz che sono gia'
    // corretti) e con una costante di tempo molto piu' lenta - insegue una
    // deriva termica lenta nell'arco della sessione, non i piccoli
    // movimenti reali che pure soddisfano il gate di quiete momento per
    // momento.
    if (accZBiasStillDuration >= requiredStillTime) {
      float gyroAlpha = dt / (GYRO_BIAS_TAU_S + dt);
      gyroBiasX += gyroAlpha * (gxFiltered - gyroBiasX);
      gyroBiasY += gyroAlpha * (gyFiltered - gyroBiasY);
      gyroBiasZ += gyroAlpha * (gzFiltered - gyroBiasZ);
    }

    float worldAccZ = constrain(worldAccZraw - accZBias, -100.0f, 100.0f); // ben sotto il fondo scala della codifica BLE

    sample.linAccX = linAccX; sample.linAccY = linAccY; sample.linAccZ = linAccZ;
    sample.worldAccX = R00 * linAccX + R01 * linAccY + R02 * linAccZ;
    sample.worldAccY = R10 * linAccX + R11 * linAccY + R12 * linAccZ;
    sample.worldAccZ = worldAccZ;
    sample.quatW = q0; sample.quatX = q1; sample.quatY = q2; sample.quatZ = q3;

    lastGyroMag = sqrt(gx * gx + gy * gy + gz * gz) * RAD_TO_DEG;
  }

  // true se la velocita' DIREZIONATA (trueVelZ*repDirectionSign - vedi
  // commento su repDirectionSign - positiva quando ci si muove nella
  // direzione tracciata, indipendentemente da Up/Down) e' <=0 - fine del
  // movimento concentrico/rumore contro-direzione. Usata per escludere
  // questi campioni SIA dalla media della fase (accumulateIntoPhase) SIA
  // dalla coda "piatta" scartata dal Guard di piattezza (integrateMotion).
  // Chiamata SEMPRE con un valore gia' moltiplicato per repDirectionSign
  // dal chiamante, mai con trueVelZ grezza.
  bool isNonPositive(float velZ) {
    return velZ <= 0.0f;
  }

  // Converte RuntimeConfig::inPhaseMinFlatWindowS (secondi, regolabile a
  // runtime via BLE - vedi MotionTracker.h) nel corrispettivo in campioni a
  // 100Hz, con clamp difensivo: un valore troppo basso vanificherebbe la
  // protezione che questo minimo esiste per dare (vedi commento in
  // CONFIGURAZIONE in cima al file); il tetto e' MAX_VELOCITY_FLAT_
  // WINDOW_SAMPLES - lo stesso usato come soffitto della finestra dinamica
  // in fase (vedi accumulateIntoPhase()), un vincolo di PRODOTTO (in fase
  // la finestra non deve mai superare quel valore) non di capacita' dei
  // buffer (quella e' FLAT_WINDOW_BUFFER_CAPACITY, ben piu' ampia) - un
  // valore scritto dall'app oltre questo tetto viene quindi limitato qui,
  // non un errore.
  uint8_t inPhaseMinFlatWindowSamples() {
    int32_t s = (int32_t)(activeConfig.inPhaseMinFlatWindowS * 100.0f + 0.5f);
    if (s < MIN_VELOCITY_FLAT_WINDOW_SAMPLES) s = MIN_VELOCITY_FLAT_WINDOW_SAMPLES;
    if (s > MAX_VELOCITY_FLAT_WINDOW_SAMPLES) s = MAX_VELOCITY_FLAT_WINDOW_SAMPLES;
    return (uint8_t)s;
  }

  // Converte RuntimeConfig::returnFlatWindowS (secondi, regolabile a runtime
  // via BLE) nel corrispettivo in campioni a 100Hz - finestra FISSA (non
  // dinamica) usata per l'intera durata dell'attesa del ritorno, vedi
  // closePhase(). Clamp difensivo fino alla capacita' REALE dei buffer
  // (FLAT_WINDOW_BUFFER_CAPACITY): a differenza di inPhaseMinFlatWindowSamples()
  // sopra, qui non c'e' un tetto di prodotto piu' stretto - piu' lunga e'
  // meglio e' per essere certi che il bilanciere si sia fermato, limitata
  // solo dalla memoria disponibile.
  uint8_t returnFlatWindowSamples() {
    int32_t s = (int32_t)(activeConfig.returnFlatWindowS * 100.0f + 0.5f);
    if (s < MIN_VELOCITY_FLAT_WINDOW_SAMPLES) s = MIN_VELOCITY_FLAT_WINDOW_SAMPLES;
    if (s > FLAT_WINDOW_BUFFER_CAPACITY) s = FLAT_WINDOW_BUFFER_CAPACITY;
    return (uint8_t)s;
  }

  // Accumula UN campione (corrente o ripescato dalla storia) nella fase
  // attualmente aperta: usata sia per il campione che ha appena aperto la
  // fase (dopo openPhase(), vedi sotto) sia per ogni campione successivo
  // finche' resta aperta. velZ e' la velocita' DIREZIONATA (vedi
  // isNonPositive sopra): sempre positiva mentre la fase resta davvero
  // aperta, tranne l'ultima coda di conferma (isNonPositive la esclude
  // dalla media, vedi sotto).
  //
  // absV e' RELATIVO a phaseStartVelZ (velocita' al momento in cui QUESTA
  // fase e' partita, vedi openPhase()), non il valore assoluto di velZ -
  // stessa logica gia' usata per lo spostamento (displacementM e'
  // relativo a phaseStartPosZ). Necessario per il ramo "touch-and-go"
  // (vedi integrateMotion()): li' la fase apre da un trueVelZ NON
  // azzerato (mai azzerata fuori dai veri momenti di chiusura, vedi nota
  // di v3.5.0 in cima al file), quindi senza questa sottrazione il picco/media riportati
  // includerebbero anche il residuo di velocita' ereditato dal ritorno
  // precedente, invece di misurare solo il contributo di QUESTA fase.
  void accumulateIntoPhase(float velZ, float accZ, float posZ, float sampleDt) {
    phaseElapsedS += sampleDt;
    float absV = fabs(velZ - phaseStartVelZ);
    float absA = fabs(accZ);

    // Esclude dal calcolo della MEDIA (velocita' E accelerazione) i
    // campioni dove trueVelZ e' gia' scesa a/sotto zero: non sono moto
    // rappresentativo per questa fase. phaseElapsedS e i PICCHI restano
    // invece calcolati su TUTTI i campioni (durata reale della fase, vedi
    // MIN_PHASE_DURATION_S) - closePhase() corregge durata/posizione per la
    // chiusura ZeroCross usando le istantanee sotto.
    if (!isNonPositive(velZ)) {
      phaseVelocitySum += absV; phaseVelocitySamples++;
      phaseAccelSum += absA; phaseAccelSamples++;
      phaseLastPositivePosZ = posZ;
      phaseLastPositiveElapsedS = phaseElapsedS;
      phaseNonPositiveTotalSamples = 0;
    } else {
      phaseNonPositiveTotalSamples++;
    }

    if (absV > phasePeakVelocity) {
      phasePeakVelocity = absV;
      // Ad ogni nuovo picco, ricalcola la dimensione delle due finestre di
      // piattezza (vedi commento su computeDynamicWindowSamples() sopra):
      // si riducono solo (mai risalgono) finche' la fase resta aperta,
      // dato che phasePeakVelocity e' un massimo monotono crescente. Minimo
      // inPhaseMinFlatWindowSamples() (non il minimo assoluto): mentre una
      // fase e' aperta serve un margine per non scambiare il picco naturale
      // di una rep veloce per un plateau vero (vedi RuntimeConfig::
      // inPhaseMinFlatWindowS, MotionTracker.h).
      uint8_t inPhaseFloor = inPhaseMinFlatWindowSamples();
      currentVelWindowSamples = computeDynamicWindowSamples(
          phasePeakVelocity, inPhaseFloor, MAX_VELOCITY_FLAT_WINDOW_SAMPLES);
      currentAccWindowSamples = computeDynamicWindowSamples(
          phasePeakVelocity, inPhaseFloor, MAX_ACCELERATION_FLAT_WINDOW_SAMPLES);
    }
    if (absA > phasePeakAcceleration) phasePeakAcceleration = absA;
  }

  // Apre una nuova fase (nella direzione tracciata, trueVelZ*repDirectionSign
  // appena salita sopra activeConfig.phaseStartVelocityMps). Ripesca dalla
  // storia (vedi PHASE_LOOKBACK_SAMPLES) i campioni PRECEDENTI gia'
  // "positivi" in senso direzionato, per non perdere la rampa iniziale sotto
  // soglia ne' nelle medie/picchi ne' nello spazio percorso. Il campione
  // CORRENTE (quello che ha superato la soglia) va accumulato a parte dal
  // chiamante subito dopo, con accumulateIntoPhase(): questa funzione si
  // occupa solo dei campioni storici e della baseline di posizione.
  //
  // startVelZ e' la baseline per accumulateIntoPhase() (vedi phaseStartVelZ):
  // per un'apertura NORMALE deve essere sempre 0.0f, non stimata dalla
  // storia - un'apertura normale scatta solo da idle vero (ne' phaseOpen ne'
  // returnPhaseOpen), e trueVelZ e' garantita 0 li' (dal Guard di piattezza,
  // da un timeout di sicurezza, o dall'azzeramento esplicito per fase
  // scartata in closePhase() - vedi nota di v3.5.0 in cima al file) e ha
  // integrato SOLO moto vero da allora, quindi l'intera rampa fino al picco
  // appartiene a questa fase (bug corretto:
  // usare come baseline il campione a PHASE_LOOKBACK_SAMPLES indietro, come
  // per phaseStartPosZ, sottostimava il picco riportato su rampe lente/lunghe
  // - piu' di 5 campioni positivi prima della soglia - perche' quel campione
  // non era affatto il vero inizio della rampa). Per il ramo "touch-and-go"
  // (vedi integrateMotion()) il chiamante passa invece il trueVelZ corrente,
  // l'UNICO caso in cui la fase parte davvero da un residuo non azzerato.
  void openPhase(float startVelZ) {
    phaseOpen = true;
    phaseElapsedS = 0;
    phaseVelocitySum = 0; phaseVelocitySamples = 0;
    phaseAccelSum = 0; phaseAccelSamples = 0;
    phasePeakVelocity = 0;
    phasePeakAcceleration = 0;
    phaseStartVelZ = startVelZ;
    phaseHadVelocityClamp = false;
    currentVelWindowSamples = MAX_VELOCITY_FLAT_WINDOW_SAMPLES;
    currentAccWindowSamples = MAX_ACCELERATION_FLAT_WINDOW_SAMPLES;

    // history[].velZ e' gia' la velocita' DIREZIONATA (vedi pushHistory() in
    // integrateMotion()), quindi ">0.0f" qui e' gia' corretto per entrambe
    // le direzioni senza bisogno di moltiplicare di nuovo per repDirectionSign.
    uint8_t nBackfill = 0;
    while (nBackfill < historyCount && nBackfill < PHASE_LOOKBACK_SAMPLES &&
           historyAgo(nBackfill).velZ > 0.0f) {
      nBackfill++;
    }

    // Baseline di posizione: refPosZ appena PRIMA del piu' vecchio campione
    // incluso (nBackfill indietro), cosi' il suo contributo (e quello di
    // tutti i campioni piu' recenti fino ad ora) entra nello spostamento
    // della fase. Se la storia disponibile e' piu' corta di nBackfill
    // (avvio sessione), si ripiega sul campione piu' vecchio disponibile
    // invece che su refPosZ corrente. (Solo la posizione usa questa stima a
    // ritroso - la velocita' usa gia' startVelZ sopra, vedi commento.)
    if (nBackfill < historyCount) {
      phaseStartPosZ = historyAgo(nBackfill).posZ;
    } else if (historyCount > 0) {
      phaseStartPosZ = historyAgo(historyCount - 1).posZ;
    } else {
      phaseStartPosZ = refPosZ;
    }
    // Default finche' accumulateIntoPhase() non aggiorna con il primo
    // campione positivo (vedi commento sulla dichiarazione).
    phaseLastPositivePosZ = phaseStartPosZ;
    phaseLastPositiveElapsedS = 0;
    phaseNonPositiveTotalSamples = 0;

    for (uint8_t k = 0; k < nBackfill; k++) {
      const HistorySample& h = historyAgo(nBackfill - 1 - k); // dal piu' vecchio al piu' recente
      accumulateIntoPhase(h.velZ, h.accZ, h.posZ, h.dt);
    }
  }

  // Chiude la fase corrente. Il trattamento di media/durata dipende dal
  // motivo (vedi PhaseCloseReason):
  //   - Flat: si esclude dalla media velocita'/accelerazione l'INTERO
  //     periodo in cui velZFlatWindow era gia' piatta per conto suo
  //     (velFlatStreakSamples/flatStreakVelocitySum/flatStreakAccelSum,
  //     vedi commento sopra la loro dichiarazione) - non solo l'ultima
  //     finestra fissa di rilevamento.
  //   - ZeroCross: la media velocita'/accelerazione e' GIA' esclusa dalla
  //     coda contro-direzione (isNonPositive() dentro accumulateIntoPhase()
  //     filtra quei campioni indipendentemente da questa funzione). Durata
  //     e spostamento pero' NON si sottraggono una coda dal valore live (a
  //     differenza di Flat): si SOSTITUISCONO con l'istantanea all'ultimo
  //     campione ancora positivo (phaseLastPositiveElapsedS/PosZ) - il
  //     valore live include anche i campioni di conferma (trueVelZ gia' a
  //     zero), che non sono moto di QUESTA fase.
  //   - Timeout: nessuna esclusione, ma quality1 forzato a 0 (vedi sotto).
  // Il picco NON viene corretto in nessun caso: per costruzione non puo'
  // cadere in una coda esclusa (il vero picco di una fase e' sempre altrove).
  // Una fase piu' corta di MIN_PHASE_DURATION_S e' scartata: non genera un
  // RepResult, come se non fosse mai avvenuta.
  //
  // Punteggio quality1 (0-100, quanto fidarsi della fase): oggi e' il solo
  // coefficiente cinematico (vedi subscoreKinematicTest sotto) - confronta
  // displacementM con la stima indipendente meanVelocity*durata, 100 =
  // nessuno scarto, 0 = scarto relativo >=100%. Forzato a 0 per Timeout.
  void closePhase(PhaseCloseReason reason) {
    float meanVelSum = phaseVelocitySum;
    int   meanVelSamples = phaseVelocitySamples;
    float meanAccSum = phaseAccelSum;
    int   meanAccSamples = phaseAccelSamples;
    uint16_t discardedTailSamples = 0;

    if (reason == PhaseCloseReason::Flat) {
      meanVelSum -= flatStreakVelocitySum;
      meanVelSamples -= (int)velFlatStreakSamples;
      meanAccSum -= flatStreakAccelSum;
      meanAccSamples -= (int)velFlatStreakSamples; // stesso conteggio della velocita', per richiesta esplicita
      // phaseElapsedS si ferma all'INIZIO della coda piatta, non alla vera
      // chiusura: unica fonte di verita' per la durata della fase, usata
      // sia dal controllo di validita' subito sotto sia da
      // expectedDisplacement piu' avanti.
      phaseElapsedS -= flatStreakElapsedS;
      discardedTailSamples = velFlatStreakSamples;
    } else if (reason == PhaseCloseReason::ZeroCross) {
      phaseElapsedS = phaseLastPositiveElapsedS;
      discardedTailSamples = phaseNonPositiveTotalSamples;
    }
    if (phaseElapsedS < 0.0f) phaseElapsedS = 0.0f; // difensivo

    if (phaseElapsedS > activeConfig.minPhaseDurationS) {
      pendingRep.repNumber = currentRepNumber;
      pendingRep.peakVelocity = phasePeakVelocity;
      pendingRep.meanVelocity = (meanVelSamples > 0) ? (meanVelSum / meanVelSamples) : 0;
      pendingRep.peakAcceleration = phasePeakAcceleration;
      pendingRep.meanAcceleration = (meanAccSamples > 0) ? (meanAccSum / meanAccSamples) : 0;
      // Per ZeroCross usa l'istantanea di posizione all'ultimo campione
      // ancora positivo, non refPosZ live - stesso motivo di phaseElapsedS
      // sopra. Per Flat, stesso principio con flatStreakStartPosZ: refPosZ
      // live a questo punto e' GIA' stata azzerata dal Guard di piattezza
      // in questo stesso campione (vedi commento sulla dichiarazione di
      // flatStreakStartPosZ) - usarla direttamente riportava displacementM
      // a ~0 per ogni fase chiusa per piattezza (bug reale: quality1 sempre
      // a 0 sullo squat, che chiude cosi' al lockout).
      float posZForDisplacement;
      if (reason == PhaseCloseReason::ZeroCross) {
        posZForDisplacement = phaseLastPositivePosZ;
      } else if (reason == PhaseCloseReason::Flat) {
        posZForDisplacement = flatStreakStartPosZ;
      } else {
        posZForDisplacement = refPosZ; // Timeout: quality1 gia' forzata a 0 sotto, nessuna coda da escludere
      }
      pendingRep.displacementM = fabs(posZForDisplacement - phaseStartPosZ);

      // Coefficiente di qualita' cinematico --- confronta displacementM
      // (doppia integrazione dell'accelerazione, la via piu' esposta a
      // deriva) con una stima indipendente meanVelocity*durata (singola
      // media, molto piu' diretta): se coincidono e' un'ulteriore conferma
      // di coerenza, se divergono e' indizio di deriva nella posizione o di
      // una fase non davvero monotona. 100 = nessun errore relativo, 0 =
      // errore relativo >=100%. Normalizzato sul MAGGIORE dei due valori
      // assoluti.
      float expectedDisplacement = pendingRep.meanVelocity * phaseElapsedS;
      float kinematicDenom = fmaxf(fabs(pendingRep.displacementM), fabs(expectedDisplacement));
      if (kinematicDenom < 0.001f) kinematicDenom = 0.001f; // entrambi trascurabili: nessun errore vero da segnalare
      float kinematicRelError = fabs(pendingRep.displacementM - expectedDisplacement) / kinematicDenom;
      uint8_t subscoreKinematicTest = (uint8_t)(100.0f - (kinematicRelError > 1.0f ? 100.0f : kinematicRelError * 100.0f));

      pendingRep.quality1 = (reason == PhaseCloseReason::Timeout) ? 0 : subscoreKinematicTest;

      // Riga CSV di fine fase (vedi RuntimeConfig::debugLogEnabled e
      // l'header stampato da REC_START in setTrackingActive()) - tipo "R",
      // per distinguerla dalle righe per-campione "S" nello stesso log.
      if (activeConfig.debugLogEnabled) {
        Serial.print("R,"); Serial.print(pendingRep.repNumber); Serial.print(',');
        Serial.print(discardedTailSamples); Serial.print(',');
        Serial.print(phasePeakVelocity, 4); Serial.print(',');
        Serial.print(pendingRep.meanVelocity, 4); Serial.print(',');
        Serial.print(phasePeakAcceleration, 4); Serial.print(',');
        Serial.print(pendingRep.meanAcceleration, 4); Serial.print(',');
        Serial.print(expectedDisplacement, 4); Serial.print(',');
        Serial.print(pendingRep.displacementM, 4); Serial.print(',');
        Serial.print(subscoreKinematicTest); Serial.print(',');
        Serial.println(reason == PhaseCloseReason::Flat ? "flat" :
                        (reason == PhaseCloseReason::Timeout ? "timeout" : "zerocross"));
      }

      repPending = true;
      currentRepNumber++;
      refPosZ = 0; // spazio percorso riparte da zero alla prossima rep
      // Attesa del ritorno: da qui in poi nessuna nuova fase puo' aprirsi (a
      // meno del ramo "touch-and-go", vedi integrateMotion()) E refVelZ (e
      // quindi sample.refVelZ, vedi update()) resta a 0 - phaseOpen e'
      // appena diventato falso qui sotto, e refVelZ e' aggiornata ogni
      // campione proprio in base a phaseOpen - finche' il movimento OPPOSTO
      // di trueVelZ non si e' a sua volta concluso - vedi returnPhaseOpen in
      // cima al file. trueVelZ VERA non viene MAI azzerata qui per il solo
      // aprirsi dell'attesa: e' il Guard di piattezza a finestra FISSA
      // (sotto, in integrateMotion()) - riparte da RuntimeConfig::
      // returnFlatWindowS qui sotto - a riportarla a zero appena si e'
      // ragionevolmente certi che il movimento di ritorno si sia davvero
      // stabilizzato.
      returnPhaseOpen = true;
      returnPhaseElapsedS = 0;
    }
    // else: fase scartata (troppo corta) - nessun RepResult, come se non fosse avvenuta.

    phaseOpen = false;
    phaseElapsedS = 0;
    phaseVelocitySum = 0; phaseVelocitySamples = 0;
    phaseAccelSum = 0; phaseAccelSamples = 0;
    phasePeakVelocity = 0;
    phasePeakAcceleration = 0;
    phaseLastPositivePosZ = 0;
    phaseLastPositiveElapsedS = 0;
    phaseNonPositiveTotalSamples = 0;
    // Se la fase e' stata scartata (troppo corta, ramo "else" sopra),
    // returnPhaseOpen e' rimasta falsa: non e' partita nessuna attesa,
    // siamo tornati direttamente in idle vero. trueVelZ deve arrivarci
    // pulita a 0 - vera per Flat/Timeout (gia' azzerata dal chiamante prima
    // di chiamare closePhase()), ma NON per ZeroCross (che di per se' non
    // azzera piu' trueVelZ, vedi nota di v3.5.0 in cima al file): senza
    // questo azzeramento esplicito, un blip scartato (rumore che sfiora la
    // soglia di apertura e torna subito sotto) lascerebbe un residuo non
    // nullo che la prossima apertura normale erediterebbe in silenzio,
    // violando l'assunzione baseline=0.0f di openPhase(). Innocuo/ridondante
    // per Flat/Timeout (gia' 0, riscriverlo non cambia nulla).
    if (!returnPhaseOpen) {
      trueVelZ = 0.0f;
    }
    // Se e' appena partita l'attesa del ritorno (sopra), le finestre
    // ripartono da RuntimeConfig::returnFlatWindowS e ci restano fisse per
    // tutta l'attesa (vedi commento di v3.5.0 in cima al file); se invece
    // la fase e' stata scartata, restano al MINIMO - siamo tornati in idle
    // vero, vedi commento sulla dichiarazione di currentVelWindowSamples.
    uint8_t returnFloor = returnFlatWindowSamples();
    currentVelWindowSamples = returnPhaseOpen ? returnFloor : MIN_VELOCITY_FLAT_WINDOW_SAMPLES;
    currentAccWindowSamples = returnPhaseOpen ? returnFloor : MIN_ACCELERATION_FLAT_WINDOW_SAMPLES;
  }

  // Chiusura forzata per timeout (vedi MAX_PHASE_DURATION_S): trueVelZ e'
  // gia' stata azzerata dal chiamante (in integrateMotion(), PRIMA
  // dell'integrazione di posizione, per restare coerente con prevTrueVelZ -
  // stesso schema del Guard di piattezza). closePhase() forza gia'
  // quality1 a 0 e stampa chiusura=timeout nella riga CSV "R" (vedi sopra):
  // nessun messaggio separato da stampare qui.
  void forceCloseTimedOutPhase() {
    closePhase(PhaseCloseReason::Timeout);
  }

  // Log dati grezzi per analisi di laboratorio (RuntimeConfig::
  // debugLogEnabled, OFF di default, vedi MotionTracker.h) - UNA riga CSV
  // per campione a 100Hz, tipo "S" per distinguerla dalla riga "R" di fine
  // fase (vedi closePhase()). Colonne descritte dall'header stampato da
  // REC_START, vedi MotionTracker::setTrackingActive().
  //
  // Sostituisce i vecchi messaggi di testo libero sparsi nei guard (urto/
  // clamp/piattezza forzata/ritorno concluso/touch-and-go, rimossi): la
  // stessa informazione e' ora nelle colonne shock/clamp/flat/touchAndGo di
  // OGNI campione (non solo sul fronte dell'evento) e nella colonna state
  // (idle/phase/return, la cui transizione rivela da sola la conclusione
  // del ritorno) - un log CSV omogeneo, senza righe di testo libero
  // intercalate, e' quello che serve per un parsing automatico affidabile
  // in laboratorio.
  //
  // UNA sola chiamata Serial.print()/print() per campo (nessuna label
  // testuale, a differenza delle vecchie righe di debug): a 100Hz il numero
  // di byte/chiamate conta, vedi nota storica di v3.4.0/v3.8.0 in cima al
  // file sul rischio di ritardare loop() (e quindi gonfiare il prossimo dt)
  // se il buffer seriale si riempie. Va comunque usato SOLO con un host
  // collegato che legga attivamente la seriale (cattura da laboratorio),
  // mai lasciato attivo durante un allenamento libero non presidiato.
  void logSampleCsv(float dt, bool touchAndGo) {
    const char* state = phaseOpen ? "phase" : (returnPhaseOpen ? "return" : "idle");
    Serial.print("S,");
    Serial.print(lastSampleTime); Serial.print(',');
    Serial.print(dt * 1000.0f, 3); Serial.print(',');
    Serial.print(state); Serial.print(',');
    Serial.print(currentRepNumber); Serial.print(',');
    Serial.print(sample.linAccX, 4); Serial.print(',');
    Serial.print(sample.linAccY, 4); Serial.print(',');
    Serial.print(sample.linAccZ, 4); Serial.print(',');
    Serial.print(sample.worldAccX, 4); Serial.print(',');
    Serial.print(sample.worldAccY, 4); Serial.print(',');
    Serial.print(sample.worldAccZ, 4); Serial.print(',');
    Serial.print(trueVelZ, 4); Serial.print(',');
    Serial.print(refVelZ, 4); Serial.print(',');
    Serial.print(worldVelX, 4); Serial.print(',');
    Serial.print(worldVelY, 4); Serial.print(',');
    Serial.print(refPosZ, 4); Serial.print(',');
    Serial.print(worldPosX, 4); Serial.print(',');
    Serial.print(worldPosY, 4); Serial.print(',');
    Serial.print(sample.quatW, 4); Serial.print(',');
    Serial.print(sample.quatX, 4); Serial.print(',');
    Serial.print(sample.quatY, 4); Serial.print(',');
    Serial.print(sample.quatZ, 4); Serial.print(',');
    Serial.print(lastGyroMag, 2); Serial.print(',');
    Serial.print(accZBias, 4); Serial.print(',');
    Serial.print(gyroBiasX, 3); Serial.print(',');
    Serial.print(gyroBiasY, 3); Serial.print(',');
    Serial.print(gyroBiasZ, 3); Serial.print(',');
    Serial.print(debugStateVar.shockRejected ? 1 : 0); Serial.print(',');
    Serial.print(debugStateVar.velocityClampedToMax ? 1 : 0); Serial.print(',');
    Serial.print(debugStateVar.velocityForcedZeroFlat ? 1 : 0); Serial.print(',');
    Serial.println(touchAndGo ? 1 : 0);
  }

  // Integrazione trapezoidale accelerazione -> velocita' -> spazio, con il
  // guard sulla velocita' e l'identificazione fase/rep applicati ad ogni
  // campione.
  void integrateMotion(float dt) {
    float rawWorldAccZ = sample.worldAccZ;
    // Vedi logSampleCsv() in fondo alla funzione.
    bool touchAndGoThisSample = false;

    debugStateVar.gyroMag = lastGyroMag;
    debugStateVar.accZBias = accZBias;
    debugStateVar.velocityClampedToMax = false;
    debugStateVar.velocityForcedZeroFlat = false;

    // --- Filtro anti-shock (jerk) ---
    // Un urto meccanico (bilanciere contro un supporto, colpo al sensore)
    // produce un salto QUASI ISTANTANEO di worldAccZ - impossibile per una
    // spinta muscolare vera, che cresce/decresce sempre gradualmente (il
    // corpo non puo' produrre una variazione di forza a gradino). Il filtro
    // mediano sull'accelerometro grezzo (vedi MedianFilter3 in cima al
    // file) protegge gia' da un singolo campione isolato, ma un urto reale
    // dura tipicamente 2-4 campioni consecutivi - troppo per essere
    // soppresso dalla mediana. Qui si guarda invece la VARIAZIONE
    // campione-a-campione di worldAccZ (gia' dopo mediana e sottrazione
    // gravita'): se supera RuntimeConfig::shockJerkThresholdMps2, il
    // campione e' scartato per l'integrazione - si tiene il valore del
    // campione precedente (worldAccZ non cambia), invece di lasciare che
    // l'impulso si integri in trueVelZ. sample.worldAccZ/rawWorldAccZ
    // restano il valore VERO (letto), solo per diagnostica/streaming - la
    // sostituzione riguarda SOLO la variabile locale worldAccZ, usata per
    // integrazione e finestre di piattezza qui sotto.
    //
    // SHOCK_MAX_CONSECUTIVE_REJECT_SAMPLES: senza questo tetto, un cambio
    // VERO e sostenuto (es. la decelerazione a fine spinta, che puo'
    // legittimamente far crollare worldAccZ di colpo) verrebbe scartato
    // UNA VOLTA correttamente, ma poi ogni campione successivo verrebbe
    // confrontato contro lo stesso riferimento ormai congelato (prevWorldAccZ
    // mai aggiornato) - trovando sempre un salto "troppo grande" e
    // rifiutando all'infinito (bug osservato su hardware: trueVelZ saliva
    // senza mai fermarsi, fino al tetto di maxPlausibleVelocityMps). Oltre
    // questo numero di rifiuti CONSECUTIVI, il filtro si arrende e accetta
    // comunque il campione corrente, risincronizzandosi sul segnale vero.
    float worldAccZ = rawWorldAccZ;
    bool jerkTooLarge = trapezoidPrimed &&
        (fabs(rawWorldAccZ - prevWorldAccZ) > activeConfig.shockJerkThresholdMps2);
    debugStateVar.shockRejected = jerkTooLarge &&
        (shockConsecutiveRejectSamples < SHOCK_MAX_CONSECUTIVE_REJECT_SAMPLES);
    if (debugStateVar.shockRejected) {
      worldAccZ = prevWorldAccZ;
      shockConsecutiveRejectSamples++;
    } else {
      shockConsecutiveRejectSamples = 0;
    }
    // Leak SOLO su X/Y (vedi VELOCITY_LEAK_XY_TAU_S in CONFIGURAZIONE) -
    // applicato PRIMA di integrare l'accelerazione di questo campione, cosi'
    // anche il primissimo campione (trapezoidPrimed=false) ne risente allo
    // stesso modo.
    float leakDecayXY = 1.0f - dt / VELOCITY_LEAK_XY_TAU_S;
    worldVelX *= leakDecayXY; worldVelY *= leakDecayXY;
    float worldAccX = sample.worldAccX, worldAccY = sample.worldAccY;
    float incrZ;
    if (!trapezoidPrimed) {
      worldVelX += worldAccX * dt; worldVelY += worldAccY * dt;
      incrZ = worldAccZ * dt;
      trapezoidPrimed = true;
    } else {
      worldVelX += (worldAccX + prevWorldAccX) * 0.5f * dt;
      worldVelY += (worldAccY + prevWorldAccY) * 0.5f * dt;
      incrZ = (worldAccZ + prevWorldAccZ) * 0.5f * dt;
    }

    // trueVelZ VERA (con segno) - nessun floor per campione, vedi commento
    // sulla dichiarazione di trueVelZ per il perche' (un floor per campione
    // confondeva "l'accelerazione e' tornata positiva" con "la velocita' e'
    // tornata positiva", facendo ripartire trueVelZ a crescere DURANTE la
    // decelerazione di fine discesa invece che al vero punto di inversione
    // - bug osservato su hardware).
    trueVelZ += incrZ;

    // Da qui in poi ogni "e' questo campione nella direzione tracciata?"
    // usa (trueVelZ * repDirectionSign), MAI trueVelZ grezza - vedi commento
    // su repDirectionSign in cima al file. trueVelZ resta sempre la velocita'
    // fisica vera; solo l'interpretazione del segno cambia con la direzione
    // configurata (Up: positiva=tracciata; Down: negativa=tracciata).
    if (isNonPositive(trueVelZ * repDirectionSign)) {
      zeroCrossStreakSamples++;
    } else {
      zeroCrossStreakSamples = 0;
    }

    // Guard sulla velocita' stimata: limite su ENTRAMBI i lati (vedi
    // RuntimeConfig::maxPlausibleVelocityMps) - nessun esercizio genera
    // velocita' oltre questo limite fisico plausibile, in nessuna delle due
    // direzioni. Simmetrico sul valore VERO (non direzionato): un limite
    // fisico non dipende da quale direzione si sta contando come rep.
    if (trueVelZ > activeConfig.maxPlausibleVelocityMps) {
      trueVelZ = activeConfig.maxPlausibleVelocityMps;
      debugStateVar.velocityClampedToMax = true;
    } else if (trueVelZ < -activeConfig.maxPlausibleVelocityMps) {
      trueVelZ = -activeConfig.maxPlausibleVelocityMps;
      debugStateVar.velocityClampedToMax = true;
    }
    // Le finestre di piattezza/streak bufferizzano il valore DIREZIONATO:
    // tutta la logica di piattezza sotto lavora quindi in "spazio
    // direzionato" (positivo=movimento tracciato), identica per Up e Down.
    velZFlatWindow.push(trueVelZ * repDirectionSign);
    accZWindow.push(worldAccZ);
    accHistoryForVelStreak.push(fabs(worldAccZ));
    posHistoryForFlatStreak.push(refPosZ);

    // --- Attesa del ritorno (returnPhaseOpen, vedi dichiarazione in cima al
    // file) --- la finestra del Guard di piattezza sotto resta FISSA al
    // MASSIMO per tutta l'attesa (impostata una sola volta in closePhase()),
    // quindi qui serve solo accumulare il tempo trascorso per il timeout di
    // sicurezza (RuntimeConfig::returnPhaseTimeoutS, vedi sotto).
    if (returnPhaseOpen) {
      returnPhaseElapsedS += dt;
    }

    // Contatore dinamico "per quanto la velocita' era piatta" (vedi
    // commento sulla dichiarazione di velFlatStreakSamples sopra): va
    // aggiornato con i valori PRIMA di un eventuale azzeramento forzato
    // sotto, cosi' resta coerente con i valori gia' bufferizzati in
    // velZFlatWindow/accHistoryForVelStreak (anch'essi pre-azzeramento).
    //
    // IMPORTANTE: conta/somma SOLO i campioni non-positivi ESCLUSI (vedi
    // isNonPositive) - deve restare coerente con l'esclusione gia'
    // applicata a phaseVelocitySum/phaseVelocitySamples in
    // accumulateIntoPhase(), altrimenti closePhase() sottrae dalla media
    // campioni che non ci sono mai entrati.
    //
    // Nessun tetto assoluto di velocita' qui (vedi nota storica in cima al
    // file, sopra RuntimeConfig::inPhaseMinFlatWindowS) - la protezione del
    // picco di una rep veloce viene invece dalla dimensione MINIMA della
    // finestra mentre una fase e' aperta (accumulateIntoPhase()), non da un
    // livello assoluto: piatto e' piatto, qualunque sia il valore.
    bool velIsFlatNow = velZFlatWindow.isFlat(currentVelWindowSamples);
    if (velIsFlatNow) {
      if (velFlatStreakSamples == 0) {
        // Prima volta che diventa piatta: velZFlatWindow/accHistoryForVelStreak
        // sono in lockstep (stesso indice ad ogni campione, pushati insieme
        // ogni volta) - si puo' quindi filtrare per direzione il campione
        // di velocita' e usare lo STESSO indice per recuperare la sua
        // accelerazione corrispondente.
        uint8_t n = (currentVelWindowSamples < velZFlatWindow.count) ? currentVelWindowSamples : velZFlatWindow.count;
        // Posizione al campione PIU' VECCHIO della finestra (i=0, vedi
        // indexOfLastWindow) = inizio retroattivo dello streak, stessa
        // convenzione di flatStreakElapsedS sotto.
        flatStreakStartPosZ = posHistoryForFlatStreak.buf[velZFlatWindow.indexOfLastWindow(n, 0)];
        uint16_t filteredCount = 0;
        float filteredVelSum = 0.0f;
        float filteredAccSum = 0.0f;
        for (uint8_t i = 0; i < n; i++) {
          uint8_t idx = velZFlatWindow.indexOfLastWindow(n, i);
          float v = velZFlatWindow.buf[idx];
          if (!isNonPositive(v)) {
            filteredCount++;
            filteredVelSum += v;
            filteredAccSum += accHistoryForVelStreak.buf[idx]; // gia' in valore assoluto
          }
        }
        velFlatStreakSamples = filteredCount;
        flatStreakVelocitySum = filteredVelSum;
        flatStreakAccelSum = filteredAccSum;
        // Nessun dt storico bufferizzato per i campioni ripescati - si
        // approssima con l'intervallo di campionamento nominale (100Hz).
        flatStreakElapsedS = n * (SAMPLE_INTERVAL_MS / 1000.0f);
      } else {
        flatStreakElapsedS += dt;
        if (!isNonPositive(trueVelZ * repDirectionSign)) {
          velFlatStreakSamples++;
          flatStreakVelocitySum += trueVelZ * repDirectionSign;
          flatStreakAccelSum += fabs(worldAccZ);
        }
      }
    } else {
      velFlatStreakSamples = 0;
      flatStreakVelocitySum = 0;
      flatStreakAccelSum = 0;
      flatStreakElapsedS = 0;
      flatStreakStartPosZ = 0;
    }

    // >0 esplicito: con zeroCrossConfirmSamples=0 lo streak dovrebbe
    // comunque richiedere ALMENO un campione non-positivo, non scattare
    // mentre lo streak e' ancora fermo a zero.
    bool zeroCrossConfirmed = phaseOpen && (zeroCrossStreakSamples > 0) &&
                               (zeroCrossStreakSamples >= activeConfig.zeroCrossConfirmSamples);

    if (velIsFlatNow && accZWindow.isFlat(currentAccWindowSamples)) {
      trueVelZ = 0.0f;
      debugStateVar.velocityForcedZeroFlat = true;
    }
    // ZeroCross confermato: NON azzera trueVelZ qui (a differenza di
    // Flat/Timeout sopra/sotto, vedi nota di v3.5.0 in cima al file) -
    // trueVelZ continua per la sua strada, senza interruzioni, dentro
    // l'eccentrica/ritorno che segue: e' phaseOpen (letto piu' sotto) a
    // diventare falso, il che basta da solo a portare refVelZ/sample.refVelZ
    // a 0 (vedi il loro aggiornamento a fine funzione) e a far scattare il
    // conteggio della rep in closePhase(). trueVelZ VERA si azzera solo
    // quando il Guard di piattezza sotto - o un timeout di sicurezza -
    // confermano che il bilanciere si e' davvero fermato.

    // Rete di sicurezza MAX_PHASE_DURATION_S (vedi commento sulla
    // dichiarazione): applicata QUI, PRIMA dell'integrazione della
    // posizione/aggiornamento di prevTrueVelZ sotto, cosi' l'azzeramento e'
    // coerente per il campione corrente E per quello successivo. phaseTimedOut
    // viene letta piu' sotto, nel blocco di identificazione fase, per
    // chiudere la fase con forceCloseTimedOutPhase() invece del percorso normale.
    bool phaseTimedOut = phaseOpen && (phaseElapsedS >= activeConfig.maxPhaseDurationS);
    if (phaseTimedOut) {
      trueVelZ = 0.0f;
    }

    // Rete di sicurezza dell'attesa del ritorno (RuntimeConfig::
    // returnPhaseTimeoutS): se il movimento opposto non si conclude MAI per
    // piattezza (rep in continuo/touch-and-go, l'atleta non si ferma mai del
    // tutto), non si puo' restare bloccati indefinitamente - trueVelZ viene
    // forzata a 0 comunque, come un normale timeout.
    bool returnTimedOut = returnPhaseOpen && (returnPhaseElapsedS >= activeConfig.returnPhaseTimeoutS);
    if (returnTimedOut) {
      trueVelZ = 0.0f;
    }
    // Conclude l'attesa del ritorno - o perche' e' appena scattato il Guard
    // di piattezza sopra (finestra fissa al massimo per tutta l'attesa,
    // vedi commento di v3.5.0 in cima al file), o per il timeout di
    // sicurezza appena applicato. Le finestre tornano al MINIMO: siamo di
    // nuovo in idle vero, in attesa della prossima soglia.
    if (returnPhaseOpen && (debugStateVar.velocityForcedZeroFlat || returnTimedOut)) {
      returnPhaseOpen = false;
      returnPhaseElapsedS = 0;
      currentVelWindowSamples = MIN_VELOCITY_FLAT_WINDOW_SAMPLES;
      currentAccWindowSamples = MIN_ACCELERATION_FLAT_WINDOW_SAMPLES;
    }

    worldPosX += (worldVelX + prevWorldVelX) * 0.5f * dt;
    worldPosY += (worldVelY + prevWorldVelY) * 0.5f * dt;
    // refPosZ segue la stessa regola della velocita' DIREZIONATA: nessun
    // valore negativo, misura SOLO lo spazio percorso nella direzione
    // tracciata. Appena trueVelZ*repDirectionSign non e' piu' positiva,
    // refPosZ si azzera immediatamente - niente da integrare durante il
    // ritorno. Questo e' sicuro (a differenza del vecchio floor per-campione
    // su trueVelZ stessa, vedi commento sulla dichiarazione di trueVelZ): qui
    // il reset dipende dal segno della velocita' direzionata, che e' gia'
    // corretto lungo tutto il movimento di ritorno (compresa la
    // decelerazione finale), non dalla propria traiettoria integrata.
    float dirVelZForPos = trueVelZ * repDirectionSign;
    float prevDirVelZForPos = prevTrueVelZ * repDirectionSign;
    if (isNonPositive(dirVelZForPos)) {
      refPosZ = 0.0f;
    } else {
      refPosZ += (dirVelZForPos + prevDirVelZForPos) * 0.5f * dt;
      // Difensivo: il solo campione di transizione (subito dopo un reset,
      // quando prevTrueVelZ e' ancora il valore del campione precedente nella
      // direzione opposta) potrebbe far scendere leggermente sotto zero la
      // media trapezoidale - refPosZ non deve mai poterlo mostrare.
      if (refPosZ < 0.0f) refPosZ = 0.0f;
    }
    prevWorldAccX = worldAccX; prevWorldAccY = worldAccY; prevWorldAccZ = worldAccZ;
    prevWorldVelX = worldVelX; prevWorldVelY = worldVelY;
    prevTrueVelZ = trueVelZ;

    // --- Identificazione fase/rep (vedi commento su RuntimeConfig::
    // phaseStartVelocityMps in cima al file) --- trueVelZ qui e' gia' il
    // valore finale, corretto dal guard sopra; accumulateIntoPhase()/
    // openPhase() lavorano pero' in "spazio direzionato" (vedi
    // isNonPositive), quindi si passa sempre trueVelZ*repDirectionSign.
    if (phaseOpen) {
      accumulateIntoPhase(trueVelZ * repDirectionSign, worldAccZ, refPosZ, dt);
      if (debugStateVar.velocityClampedToMax) phaseHadVelocityClamp = true;

      // Una fase si chiude in uno di tre modi, in quest'ordine di priorita'
      // (vedi PhaseCloseReason): timeout (rete di sicurezza assoluta) >
      // Guard di piattezza combinato > trueVelZ VERA a/sotto zero confermata.
      if (phaseTimedOut) {
        forceCloseTimedOutPhase();
      } else if (debugStateVar.velocityForcedZeroFlat) {
        closePhase(PhaseCloseReason::Flat);
      } else if (zeroCrossConfirmed) {
        closePhase(PhaseCloseReason::ZeroCross);
      }
    }
    // Una fase inizia quando la velocita' DIREZIONATA supera la soglia
    // POSITIVA - nessun fabs(): sotto una fase non esiste apertura sul lato
    // opposto. Se questo campione ha appena chiuso la fase precedente per
    // ZeroCross, trueVelZ*repDirectionSign e' per costruzione <=0 (e' cio'
    // che ha fatto scattare zeroCrossConfirmed sopra, trueVelZ NON viene
    // azzerata qui, vedi nota di v3.5.0 in cima al file), quindi non puo'
    // anche superare la soglia POSITIVA di riapertura nello stesso campione.
    bool crossedThreshold = (trueVelZ * repDirectionSign) >= activeConfig.phaseStartVelocityMps;
    if (!phaseOpen && !returnPhaseOpen && crossedThreshold) {
      openPhase(0.0f); // apertura normale: baseline SEMPRE 0, vedi commento su openPhase()
      accumulateIntoPhase(trueVelZ * repDirectionSign, worldAccZ, refPosZ, dt); // include anche il campione che ha appena aperto la fase
      if (debugStateVar.velocityClampedToMax) phaseHadVelocityClamp = true;
    } else if (!phaseOpen && returnPhaseOpen && crossedThreshold) {
      // "Touch-and-go": la soglia di apertura e' stata ri-superata PRIMA che
      // l'attesa del ritorno si concludesse da sola (flat/timeout, vedi
      // sopra) - l'atleta non ha fatto una vera pausa tra una rep e l'altra.
      // Si considera l'attesa implicitamente conclusa invece di bloccare una
      // rep vera che sta gia' ripartendo (vedi RuntimeConfig::
      // returnPhaseTimeoutS per il tetto massimo di attesa "normale").
      // touchAndGoThisSample: flag per la riga CSV "S" di questo campione
      // (vedi logSampleCsv sotto) - un riapertura normale nello stesso
      // campione in cui il ritorno si conclude per conto suo (colonna state
      // che passa da "return" a "phase" senza un "idle" in mezzo) sarebbe
      // indistinguibile da questo caso guardando solo state/rep.
      touchAndGoThisSample = true;
      returnPhaseOpen = false;
      returnPhaseElapsedS = 0;
      // Baseline = il residuo VERO ereditato dal ritorno interrotto (unico
      // caso in cui non e' 0, vedi commento su openPhase()).
      openPhase(trueVelZ * repDirectionSign);
      accumulateIntoPhase(trueVelZ * repDirectionSign, worldAccZ, refPosZ, dt);
      if (debugStateVar.velocityClampedToMax) phaseHadVelocityClamp = true;
    }

    // Storia per il backfill di openPhase(): pushata per ULTIMA, con lo
    // stato gia' definitivo di questo campione (incluso un eventuale
    // azzeramento di refPosZ appena avvenuto in closePhase() a fine rep).
    // Memorizza gia' il valore DIREZIONATO (vedi il ">0.0f" in openPhase()).
    pushHistory(trueVelZ * repDirectionSign, worldAccZ, refPosZ, dt);

    // refVelZ (variabile di stato esplicita, vedi dichiarazione e commento
    // di v3.5.0 in cima al file): aggiornata per ULTIMA, quando phaseOpen e'
    // gia' lo stato FINALE di questo campione (ogni apertura/chiusura sopra
    // e' gia' avvenuta) - SOLO mentre una fase concentrica e' aperta,
    // altrimenti 0 (compreso il campione stesso in cui la fase si chiude:
    // phaseOpen e' gia' falso a questo punto).
    //
    // RIBASATA su phaseStartVelZ, ESATTAMENTE come accumulateIntoPhase() fa
    // per absV/phasePeakVelocity/phaseVelocitySum (vedi commento li' e su
    // phaseStartVelZ): per un'apertura normale phaseStartVelZ e' 0.0f,
    // quindi qui non cambia nulla. Per un'apertura "touch-and-go" pero'
    // phaseStartVelZ NON e' zero - senza la STESSA sottrazione qui,
    // refVelZ (quindi anche il grafico live nell'app, che mostra proprio
    // questo valore in streaming) mostrerebbe la velocita' DIREZIONATA
    // grezza, mentre il picco/media riportati a chiusura fase misurano SOLO
    // il contributo NETTO di questa fase - la stessa identica rep
    // apparirebbe con un picco diverso sul grafico live rispetto al
    // riepilogo finale (bug segnalato dall'utente: "peak velocity a volte
    // non combacia con quella nel grafico live"). Le due piste devono
    // condividere la STESSA definizione di "velocita' di questa fase".
    refVelZ = phaseOpen ? fmaxf(0.0f, (trueVelZ * repDirectionSign) - phaseStartVelZ) : 0.0f;

    if (activeConfig.debugLogEnabled) {
      logSampleCsv(dt, touchAndGoThisSample);
    }
  }
}

bool MotionTracker::begin() {
  // L'IMU e' su un rail 3V3 switchato sulla XIAO nRF52840 Sense: va acceso prima di leggerlo.
  pinMode(PIN_LSM6DS3TR_C_POWER, OUTPUT);
  digitalWrite(PIN_LSM6DS3TR_C_POWER, HIGH);
  delay(10);

  bool ok = (imu.begin() == 0);
  // imu.begin() chiama Wire.begin() internamente (clock di default,
  // tipicamente 100kHz): alzarlo a 400kHz (Fast Mode, supportato dal
  // LSM6DS3 e dal TWI dell'nRF52840) DOPO, altrimenti verrebbe
  // sovrascritto. Dimezza il tempo per transazione I2C, in aggiunta al
  // burst-read di FastSampleAccumulator::poll().
  Wire.setClock(400000);
  return ok;
}

void MotionTracker::calibrateOrientation() {
  float sumAx = 0, sumAy = 0, sumAz = 0;
  float sumGx = 0, sumGy = 0, sumGz = 0;
  // Range (max-min) delle letture giroscopio durante la finestra: se il
  // dispositivo NON era davvero fermo la media non e' piu' un bias pulito
  // ma include un pezzo di rotazione vera - un bias sbagliato peggiora la
  // deriva invece di correggerla. Si traccia qui per poter avvisare invece
  // di accettare silenziosamente una stima contaminata.
  float minGx = 1e9f, maxGx = -1e9f, minGy = 1e9f, maxGy = -1e9f, minGz = 1e9f, maxGz = -1e9f;
  for (uint16_t i = 0; i < CALIBRATION_SAMPLES; i++) {
    // Usa lo stesso percorso ROBUSTO del resto del firmware (poll() su
    // STATUS_REG, legge solo quando XLDA/GDA segnala un campione davvero
    // pronto, poi harvest() ne fa la media) invece delle letture singole
    // dirette. poll() ripetuto per tutta la finestra di
    // CALIBRATION_SAMPLE_DELAY_MS (non una singola chiamata) per
    // accumulare/mediare tutti i campioni realmente arrivati nel frattempo,
    // esattamente come fa loop() a runtime.
    float ax, ay, az, gx, gy, gz;
    for (uint8_t retry = 0; ; retry++) {
      unsigned long windowStart = millis();
      do {
        fastSamples.poll();
      } while (millis() - windowStart < CALIBRATION_SAMPLE_DELAY_MS);
      fastSamples.harvest(ax, ay, az, gx, gy, gz);

      // Rigetto outlier (vedi CALIBRATION_OUTLIER_REJECT_DEG_S): confronta
      // col la media dei soli campioni GIA' accettati finora (non con zero -
      // ogni asse ha il suo bias fisiologico, es. gy tipicamente ~-1.5
      // deg/s). Senza media di riferimento ancora (i==0) o dopo troppi
      // tentativi (dispositivo forse davvero in movimento), accetta
      // comunque quello che c'e' - meglio un campione dubbio isolato che
      // un blocco indefinito.
      if (i == 0 || retry >= CALIBRATION_OUTLIER_MAX_RETRIES) break;
      float meanGx = sumGx / i, meanGy = sumGy / i, meanGz = sumGz / i;
      bool isOutlier = fabs(gx - meanGx) > CALIBRATION_OUTLIER_REJECT_DEG_S ||
                        fabs(gy - meanGy) > CALIBRATION_OUTLIER_REJECT_DEG_S ||
                        fabs(gz - meanGz) > CALIBRATION_OUTLIER_REJECT_DEG_S;
      if (!isOutlier) break;
      // DEBUG: per confermare sul campo che il filtro sta davvero
      // intercettando i glitch (non solo che il risultato finale e' pulito).
      Serial.print("CAL i="); Serial.print(i);
      Serial.print(" SCARTATO gx="); Serial.print(gx, 3);
      Serial.print(" gy="); Serial.print(gy, 3);
      Serial.print(" gz="); Serial.print(gz, 3);
      Serial.print(" (media finora: gx="); Serial.print(meanGx, 3);
      Serial.print(" gy="); Serial.print(meanGy, 3);
      Serial.print(" gz="); Serial.print(meanGz, 3);
      Serial.println(")");
    }
    sumAx += ax; sumAy += ay; sumAz += az;
    // Stessa finestra di quiete usata per l'allineamento a gravita': la
    // media delle letture grezze del giroscopio da fermo E' il bias
    // (zero-rate offset).
    sumGx += gx; sumGy += gy; sumGz += gz;
    minGx = min(minGx, gx); maxGx = max(maxGx, gx);
    minGy = min(minGy, gy); maxGy = max(maxGy, gy);
    minGz = min(minGz, gz); maxGz = max(maxGz, gz);
    // DEBUG: per verificare sul campo l'assenza di outlier isolati dopo
    // questa correzione (vedi commento sopra). ax/ay/az aggiunti per poter
    // misurare il rumore VERO dell'accelerometro da fermo.
    Serial.print("CAL i="); Serial.print(i);
    Serial.print(" ax="); Serial.print(ax, 4);
    Serial.print(" ay="); Serial.print(ay, 4);
    Serial.print(" az="); Serial.print(az, 4);
    Serial.print(" gx="); Serial.print(gx, 3);
    Serial.print(" gy="); Serial.print(gy, 3);
    Serial.print(" gz="); Serial.println(gz, 3);
  }
  float meanAx = sumAx / CALIBRATION_SAMPLES;
  float meanAy = sumAy / CALIBRATION_SAMPLES;
  float meanAz = sumAz / CALIBRATION_SAMPLES;
  ahrs.alignToGravity(meanAx, meanAy, meanAz);
  gyroBiasX = sumGx / CALIBRATION_SAMPLES;
  gyroBiasY = sumGy / CALIBRATION_SAMPLES;
  gyroBiasZ = sumGz / CALIBRATION_SAMPLES;
  // Scala reale di QUESTO accelerometro (vedi commento sulla dichiarazione
  // di accelScaleG): da fermo il modulo del vettore accelerazione DEVE
  // essere esattamente G - se questo sensore legge un modulo diverso, e' un
  // errore di scala/offset di fabbrica, non moto vero (il dispositivo e'
  // fermo per costruzione di questa finestra). Il fattore correttivo
  // sostituisce G ovunque in updateOrientationAndAcceleration(). Clamp
  // difensivo: oltre +-15% e' piu' probabile un errore di calibrazione/
  // movimento durante la finestra che un vero errore di scala del sensore.
  float measuredMagG = sqrt(meanAx * meanAx + meanAy * meanAy + meanAz * meanAz);
  if (measuredMagG > 0.85f && measuredMagG < 1.15f) {
    accelScaleG = G / measuredMagG;
    Serial.print("Scala accelerometro: modulo misurato="); Serial.print(measuredMagG, 4);
    Serial.print("g (ideale 1.0000g), accelScaleG="); Serial.print(accelScaleG, 4);
    Serial.println(" m/s^2/g (era G ideale=9.8066).");
  } else {
    accelScaleG = G;
    Serial.print("ATTENZIONE: modulo accelerometro da fermo implausibile (");
    Serial.print(measuredMagG, 4);
    Serial.println("g, atteso vicino a 1.0) - scala NON corretta, uso G ideale.");
  }
  // La stima del bias di worldAccZ riparte da zero ad ogni calibrazione:
  // e' relativa all'orientamento appena allineato, quindi un valore
  // ereditato da prima non avrebbe senso. Riconverge in pochi secondi.
  accZBias = 0;
  accZBiasStillDuration = 0;
  lastSampleTime = millis();
  calibrated = true;

  float rangeX = maxGx - minGx, rangeY = maxGy - minGy, rangeZ = maxGz - minGz;
  float maxRange = max(rangeX, max(rangeY, rangeZ));
  if (maxRange > CALIBRATION_GYRO_RANGE_WARN_DEG_S) {
    Serial.print("ATTENZIONE: durante CALIBRATE il dispositivo non sembrava fermo "
                 "(range giroscopio ");
    Serial.print(maxRange, 1);
    Serial.println(" deg/s, atteso <3). Bias stimato POTREBBE essere impreciso: "
                    "ripeti CALIBRATE tenendo davvero fermo il dispositivo/barra.");
  }
}

bool MotionTracker::isCalibrated() { return calibrated; }

void MotionTracker::setTrackingActive(bool active) {
  bool wasActive = trackingActive;
  trackingActive = active;
  resetIntegration();
  resetPhaseTracking();
  // Marcatori + header CSV per il log dati grezzi (vedi RuntimeConfig::
  // debugLogEnabled) - stampati una volta all'avvio/fine tracciamento,
  // cosi' uno script di analisi puo' delimitare la sessione e conoscere le
  // colonne senza doverle avere hardcoded. Vedi logSampleCsv() e la riga
  // "R" in closePhase(), MotionTracker.cpp, per l'ordine esatto dei campi.
  if (activeConfig.debugLogEnabled) {
    if (active) {
      Serial.println("REC_START");
      Serial.println("S,t_ms,dt_ms,state,rep,linAccX,linAccY,linAccZ,worldAccX,worldAccY,worldAccZ,"
                      "trueVelZ,refVelZ,worldVelX,worldVelY,refPosZ,worldPosX,worldPosY,"
                      "quatW,quatX,quatY,quatZ,gyroMag,accZBias,gyroBiasX,gyroBiasY,gyroBiasZ,"
                      "shockRejected,velClamped,velForcedFlat,touchAndGo");
      Serial.println("R,rep,discardedTailSamples,peakVelocity,meanVelocity,peakAcceleration,"
                      "meanAcceleration,expectedDisplacement,displacementM,quality1,closeReason");
    } else if (wasActive) {
      Serial.println("REC_STOP");
    }
  }
}

bool MotionTracker::isTrackingActive() { return trackingActive; }

void MotionTracker::setConfig(const RuntimeConfig& config) {
  activeConfig = config;
  repDirectionSign = (config.repDirection == RepDirection::Down) ? -1 : 1;
}

const RuntimeConfig& MotionTracker::currentConfig() { return activeConfig; }

const RuntimeConfig& MotionTracker::defaultConfig() { return DEFAULT_CONFIG; }

bool MotionTracker::update() {
  // Interrogazione veloce del sensore ad OGNI chiamata (cioe' ad ogni giro
  // di loop(), molto piu' spesso dei 10ms sotto): accumula nel frattempo
  // tutti i campioni realmente nuovi, vedi FastSampleAccumulator::poll().
  // L'elaborazione vera (Madgwick/integrazione, sotto) resta gated a
  // 10ms come prima - qui si evita solo di perdere i campioni intermedi.
  fastSamples.poll();

  unsigned long now = millis();
  if (now - lastSampleTime < SAMPLE_INTERVAL_MS) return false; // nessun campione nuovo: no-op
  float dt = (now - lastSampleTime) / 1000.0f;
  lastSampleTime = now;

  updateOrientationAndAcceleration(dt);

  if (!trackingActive) {
    sample.worldVelX = sample.worldVelY = 0;
    sample.refVelZ = 0;
    sample.worldPosX = sample.worldPosY = sample.worldPosZ = 0;
    return true;
  }

  integrateMotion(dt);

  // sample.refVelZ rispecchia 1:1 la variabile di stato refVelZ (aggiornata
  // ogni campione in fondo a integrateMotion(), vedi il commento di v3.5.0 in
  // cima al file) - vale SOLO mentre phaseOpen e' vero: prima che la fase
  // apra, e dopo che si e' chiusa e finche' l'attesa del ritorno
  // (returnPhaseOpen) non si conclude, resta a 0. La variabile interna
  // trueVelZ resta VERA (con segno) per tutta la logica di apertura/chiusura
  // fase/attesa, ma cio' che viene riportato/trasmesso e' sempre >=0
  // indipendentemente dalla direzione configurata (Up o Down): il ritorno
  // alla posizione iniziale non viene mai mostrato.
  sample.worldVelX = worldVelX; sample.worldVelY = worldVelY;
  sample.refVelZ = refVelZ;
  sample.worldPosX = worldPosX; sample.worldPosY = worldPosY; sample.worldPosZ = refPosZ;
  return true;
}

const MotionSample& MotionTracker::currentSample() { return sample; }

bool MotionTracker::takeCompletedRep(RepResult& outResult) {
  if (!repPending) return false;
  outResult = pendingRep;
  repPending = false;
  return true;
}

const MotionDebugState& MotionTracker::debugState() { return debugStateVar; }
