#ifndef BATTERY_MONITOR_H
#define BATTERY_MONITOR_H

#include <Arduino.h>

// Lettura della LiPo 3.7V/360mAh tramite il partitore onboard della XIAO
// nRF52840 Sense (VBAT_ENABLE / PIN_VBAT). NOTA: il fattore di
// compensazione del partitore (VBAT_DIVIDER_COMP, in BatteryMonitor.cpp)
// non e' pubblicato ufficialmente da Seeed; e' preso da un'implementazione
// di terzi, e il rapporto reale del partitore puo' variare leggermente da
// scheda a scheda (tolleranza componenti). Per questo readVoltage() applica
// ANCHE un fattore di correzione per-dispositivo, appreso automaticamente
// e persistito in flash - vedi il commento su AUTO-CALIBRAZIONE in
// BatteryMonitor.cpp.
namespace BatteryMonitor {
  void begin();
  float readVoltage();                    // Volt - gia' calibrata (vedi sopra)
  float voltageToPercent(float volts);    // 0-100

  // true mentre il ~CHG del BQ25100 (D23/P0.17) segnala carica in corso -
  // vedi commento su AUTO-CALIBRAZIONE in BatteryMonitor.cpp. Diagnostico:
  // nessuna logica di fase/rep dipende da questo.
  bool isCharging();
}

#endif
