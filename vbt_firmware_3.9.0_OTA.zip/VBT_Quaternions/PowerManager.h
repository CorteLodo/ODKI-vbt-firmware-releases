#ifndef POWER_MANAGER_H
#define POWER_MANAGER_H

#include <Arduino.h>

// Gestione switch di accensione (WAKE_PIN, vedi Config.h), deep sleep e
// watchdog hardware.
//
// WATCHDOG: rete di sicurezza contro blocchi del firmware (crash, hard
// fault, hang su I2C/BLE/USB) che altrimenti lascerebbero il dispositivo
// "morto" - LED spento, nessuna risposta allo switch - fino a uno
// scollegamento fisico dell'alimentazione. E' il caso diagnosticato in
// precedenza: un blocco prima del completamento di goToSleep() lascia la
// CPU bloccata in uno stato che NON e' vero System OFF, quindi il
// meccanismo SENSE/DETECT sul WAKE_PIN (che funziona solo per risvegliare
// da un vero System OFF) non ha alcun modo di intervenire.
//
// Il watchdog dell'nRF52840, una volta avviato, non puo' essere fermato via
// software (solo un reset lo azzera) - begin() lo avvia una sola volta e
// per tutta la vita del programma va "nutrito" periodicamente con
// feedWatchdog(), altrimenti scade e forza un reset completo (equivalente
// a togliere e ridare corrente, ma automatico). Dopo un reset da watchdog,
// lastResetReason() riportera' il bit DOG impostato: e' la prova che serve
// per confermare (o escludere) che un blocco del genere si sia
// effettivamente verificato tra un avvio e l'altro.
namespace PowerManager {
  void begin();
  bool wakeSwitchClosed();
  void goToSleep(); // System OFF: non ritorna mai, il risveglio riparte da un reset completo
  uint32_t lastResetReason(); // NRF_POWER->RESETREAS letto in begin(), per diagnosticare il wake
  void feedWatchdog(); // da chiamare ad ogni giro di loop() - vedi commento sopra
}

#endif
