#include "PowerManager.h"
#include "StatusLED.h"
#include "Config.h"
#include "nrf_gpio.h"
#include <bluefruit.h> // per sd_power_system_off()

namespace {
  uint32_t g_lastResetReas = 0;

  // Timeout scelto con margine ampio sopra il blocco piu' lungo che il
  // firmware compie normalmente senza mai richiamare feedWatchdog():
  //   - attesa Serial in setup(): fino a 3000ms
  //   - MotionTracker::calibrateOrientation(), chiamata da loop() in
  //     risposta al comando BLE CALIBRATE: CALIBRATION_SAMPLES (200) *
  //     CALIBRATION_SAMPLE_DELAY_MS (10ms) = 2000ms bloccanti
  // 8000ms lascia oltre 2x di margine sopra il caso peggiore misurato
  // (setup completo, tipicamente 3-4s) senza essere cosi' lungo da
  // vanificare lo scopo della rete di sicurezza.
  const uint32_t WATCHDOG_TIMEOUT_MS = 8000;
}

uint32_t PowerManager::lastResetReason() {
  return g_lastResetReas;
}

void PowerManager::begin() {
  pinMode(WAKE_PIN, INPUT_PULLUP);

  // DIAGNOSTICA TEMPORANEA: motivo dell'ultimo reset (letto e azzerato il
  // prima possibile, prima che qualunque altro modulo possa alterarlo).
  // Bit rilevanti (NRF_POWER->RESETREAS):
  //   bit 0  RESETPIN - reset da pin RESET fisico
  //   bit 1  DOG      - watchdog (vedi sotto)
  //   bit 2  SREQ     - reset software richiesto
  //   bit 3  LOCKUP   - CPU lockup (crash hard fault non gestito)
  //   bit 16 OFF      - risveglio da System OFF via GPIO DETECT/SENSE
  //   (0 su tutti i bit = Power-On Reset "vero", es. da spina USB)
  g_lastResetReas = NRF_POWER->RESETREAS;
  NRF_POWER->RESETREAS = NRF_POWER->RESETREAS; // clear-on-write-1

  // --- Watchdog hardware (WDT), vedi il commento in PowerManager.h ---
  //
  // CONFIG.SLEEP = Run: il WDT continua a contare anche quando la CPU e' in
  // WFI/idle (usato internamente da delay() e dallo stack BLE tra un
  // evento e l'altro) - un vero hang deve poter scattare il reset anche se
  // capita mentre la CPU e' "addormentata" in questo senso (NON e' il
  // System OFF di goToSleep(): quello spegne il WDT stesso, vedi sotto).
  //
  // CONFIG.HALT = Pause: mentre un debugger tiene la CPU ferma su un
  // breakpoint, il WDT NON continua a contare. Comodo in sviluppo (un
  // breakpoint prolungato non genera un reset spurio); se in futuro serve
  // che il watchdog sia "vero" anche sotto debugger, cambiare in Run.
  NRF_WDT->CONFIG = (WDT_CONFIG_SLEEP_Run << WDT_CONFIG_SLEEP_Pos) |
                     (WDT_CONFIG_HALT_Pause << WDT_CONFIG_HALT_Pos);

  // CRV e' in tick del clock a bassa frequenza (LFCLK, 32768 Hz).
  NRF_WDT->CRV = (WATCHDOG_TIMEOUT_MS * 32768UL) / 1000UL;

  // Un solo "reload register" (RR0): e' l'unico che feedWatchdog() nutre.
  NRF_WDT->RREN = WDT_RREN_RR0_Msk;

  // Una volta lanciato il WDT non si puo' piu' fermare via software (solo
  // un reset lo azzera) - e' voluto: se si potesse disabilitare, un
  // firmware bloccato potrebbe restare bloccato anche con un bug che
  // disabilita per errore proprio la rete di sicurezza che dovrebbe
  // salvarlo.
  //
  // NOTA IMPORTANTE sull'interazione con goToSleep(): il WDT dell'nRF52840
  // NON e' tra le periferiche con retention in System OFF - si spegne con
  // tutto il resto. Non serve quindi fermarlo esplicitamente prima di
  // sd_power_system_off(): la sua conta si azzera li' per forza. Al
  // risveglio (reset completo, setup() rieseguito da capo) begin() lo
  // riarma da zero automaticamente.
  NRF_WDT->TASKS_START = 1;
}

// Da chiamare ad ogni giro di loop() (mai nei loop di attesa/errore, es.
// quello di "IMU non inizializzato" in setup()): se il firmware resta
// bloccato li' dentro, o in un hang dentro goToSleep() prima che
// sd_power_system_off() completi, il WDT NON viene nutrito e scade da
// solo entro WATCHDOG_TIMEOUT_MS, forzando un reset che rimette in moto
// il dispositivo senza intervento manuale. E' voluto: un loop di errore
// che si "auto-guarisce" via reset periodico e' un effetto collaterale
// accettabile (e in questo caso desiderabile: es. un I2C dell'IMU
// incastrato transitoriamente puo' risolversi da solo al retry).
void PowerManager::feedWatchdog() {
  NRF_WDT->RR[0] = WDT_RR_RR_Reload;
}

bool PowerManager::wakeSwitchClosed() {
  return digitalRead(WAKE_PIN) == LOW;
}

void PowerManager::goToSleep() {
  StatusLED::off();

  Serial.println("Switch aperto: vado in deep sleep...");
  Serial.flush();
  delay(50);

  // Configura WAKE_PIN come sense input: sveglia quando va LOW
  // (cioe' quando lo switch lo collega a GND)
  uint32_t pin = g_ADigitalPinMap[WAKE_PIN];
  nrf_gpio_cfg_sense_input(pin, NRF_GPIO_PIN_PULLUP, NRF_GPIO_PIN_SENSE_LOW);

  // DIAGNOSTICA TEMPORANEA: verifica che il registro PIN_CNF del WAKE_PIN
  // abbia davvero SENSE=LOW (atteso: bit[17:16] = 0b11) e INPUT abilitato
  // (bit1 = 0). Se questo stampa un valore diverso da quanto atteso, il
  // problema e' nella configurazione software del pin, non nello switch.
  Serial.print("WAKE_PIN mappato a pin nRF #");
  Serial.print(pin);
  Serial.print(", PIN_CNF = 0x");
  Serial.println(NRF_GPIO->PIN_CNF[pin], HEX);
  Serial.flush();

  // System OFF: consumo minimo possibile sull'nRF52840.
  // Il risveglio riparte da un reset completo (setup() rieseguito).
  //
  // NOTA: con il SoftDevice BLE attivo, scrivere direttamente su
  // NRF_POWER->SYSTEMOFF e' bloccato/ignorato in modo non deterministico
  // (il SoftDevice protegge quel registro) - e' la causa del bug per cui
  // il dispositivo a volte non si addormentava. La chiamata corretta e
  // sicura col SoftDevice attivo e' sd_power_system_off(). Richiede che
  // Bluefruit.begin() sia gia' stato chiamato (vedi ordine in setup()).
  sd_power_system_off();
  while (1); // non si arriva mai qui
}
