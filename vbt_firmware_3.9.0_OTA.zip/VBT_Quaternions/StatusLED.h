#ifndef STATUS_LED_H
#define STATUS_LED_H

#include <Arduino.h>

// LED RGB "USR" di stato. Va chiamato StatusLED::update(...) ad ogni ciclo
// di loop() con lo stato corrente: il colore e' ricalcolato da zero ogni
// volta (non ci sono transizioni "una tantum" da tenere sincronizzate a
// mano), cosi' non puo' restare disallineato dopo eventi come una
// disconnessione BLE a meta' streaming.
//
//   Non connesso           -> ROSSO lampeggiante
//   Connesso, non calibrato -> ROSSO fisso
//   Connesso, calibrato, tracciamento fermo -> VERDE
//   Connesso, calibrato, tracciamento attivo -> BLU
//
// Non riflette lo stato di carica della batteria: per quello si usa il
// LED "CH" hardware dedicato della scheda, pilotato direttamente dal
// BQ25100.
namespace StatusLED {
  void begin();
  void update(bool connected, bool calibrated, bool trackingActive);
  void off(); // usato solo da PowerManager per il deep sleep
}

#endif
