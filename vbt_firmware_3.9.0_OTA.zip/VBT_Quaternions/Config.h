#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// Switch di accensione: chiuso (a GND) = dispositivo acceso.
#define WAKE_PIN D6

// Versione firmware, esposta via BLE come stringa "MAJOR.MINOR.PATCH" sul
// Device Information Service standard (vedi deviceInfoService in
// BleServer.cpp) cosi' l'app puo' confrontarla con l'ultima disponibile e
// proporre l'aggiornamento OTA (BLE DFU, vedi Adafruit_BLEDFU in
// BleServer.cpp) senza che il tester debba fare nulla di manuale.
// Da incrementare ad OGNI release inviata ai tester.
namespace FirmwareVersion {
  const uint8_t MAJOR = 3;
  const uint8_t MINOR = 9;
  const uint8_t PATCH = 0;
}

namespace Config {
  // Ogni quanto stampare/notificare lo stato della batteria.
  const unsigned long BATTERY_CHECK_INTERVAL_MS = 30000UL;

  // Il campionamento IMU interno gira a 100Hz (vedi MotionTracker), ma lo
  // streaming BLE viene inviato 1 campione ogni N per non saturare la
  // connessione: 100Hz / 5 = 20Hz via BLE.
  const uint8_t STREAM_DECIMATION_FACTOR = 5;
}

#endif
