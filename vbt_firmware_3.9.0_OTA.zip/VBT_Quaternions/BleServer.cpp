#include "BleServer.h"
#include "Config.h"
#include <bluefruit.h>
// BLEDfu (classe della stessa Bluefruit52Lib, vedi bluefruit.h): friend
// service del bootloader Adafruit, espone la sola characteristic
// "buttonless DFU" (scrivendoci, il device si riavvia in bootloader, che
// espone il VERO servizio Secure DFU Nordic per il trasferimento - questo
// secondo passaggio e' interamente gestito dal bootloader di fabbrica, MAI
// da questo file). Le librerie DFU lato app (es. nordic_dfu su Flutter)
// riconoscono questo servizio automaticamente.

namespace {
  // UUID base generato una tantum (random v4): 6c7325bb-1784-4d77-8b99-89ce838ac2ab
  // Le characteristic derivano incrementando l'ultimo byte. Gli array sono
  // in ordine little-endian (byte meno significativo per primo), come
  // richiesto da BLECharacteristic/BLEService di Bluefruit52Lib. 0xAE e 0xB1
  // (Battery/FirmwareVersion custom) sono stati liberati: quei dati usano
  // ora i servizi standard SIG (BLEBas/BLEDis sotto), non fanno piu' parte
  // di questo servizio custom.
  const uint8_t UUID_SERVICE[]      = {0xAB,0xC2,0x8A,0x83,0xCE,0x89,0x99,0x8B,0x77,0x4D,0x84,0x17,0xBB,0x25,0x73,0x6C};
  const uint8_t UUID_CHR_STREAM[]   = {0xAC,0xC2,0x8A,0x83,0xCE,0x89,0x99,0x8B,0x77,0x4D,0x84,0x17,0xBB,0x25,0x73,0x6C};
  const uint8_t UUID_CHR_REPSUM[]   = {0xAD,0xC2,0x8A,0x83,0xCE,0x89,0x99,0x8B,0x77,0x4D,0x84,0x17,0xBB,0x25,0x73,0x6C};
  const uint8_t UUID_CHR_SYSSTAT[]  = {0xAF,0xC2,0x8A,0x83,0xCE,0x89,0x99,0x8B,0x77,0x4D,0x84,0x17,0xBB,0x25,0x73,0x6C};
  const uint8_t UUID_CHR_COMMAND[]  = {0xB0,0xC2,0x8A,0x83,0xCE,0x89,0x99,0x8B,0x77,0x4D,0x84,0x17,0xBB,0x25,0x73,0x6C};
  const uint8_t UUID_CHR_CONFIG[]   = {0xB2,0xC2,0x8A,0x83,0xCE,0x89,0x99,0x8B,0x77,0x4D,0x84,0x17,0xBB,0x25,0x73,0x6C};

  BLEService        vbtService(UUID_SERVICE);
  BLECharacteristic streamChr(UUID_CHR_STREAM);
  BLECharacteristic repSummaryChr(UUID_CHR_REPSUM);
  BLECharacteristic systemStatusChr(UUID_CHR_SYSSTAT);
  BLECharacteristic commandChr(UUID_CHR_COMMAND);
  BLECharacteristic configChr(UUID_CHR_CONFIG);

  // Servizi standard Bluetooth SIG - vedi commento sul layout in BleServer.h.
  BLEBas batteryService;
  BLEDis deviceInfoService;

  // Buttonless DFU: friend service del bootloader, vedi commento sopra.
  BLEDfu bledfu;

  volatile bool startRequested = false;
  volatile bool stopRequested = false;
  volatile bool calibrateRequested = false;
  volatile bool configUpdateAvailable = false;
  RuntimeConfig pendingConfig;

  bool lastCalibrated = false;
  bool lastTrackingActive = false;

  // Converte un float in intero con fattore di scala fisso, arrotondando
  // al valore piu' vicino (non troncando) e con clamp al range di int16_t
  // per evitare wraparound in caso di valori fuori scala.
  int16_t toFixed16(float value, float scale) {
    float scaled = value * scale;
    scaled = constrain(scaled, -32767.0f, 32767.0f);
    return (int16_t)(scaled >= 0.0f ? scaled + 0.5f : scaled - 0.5f);
  }

  uint16_t toFixedU16(float value, float scale) {
    float scaled = value * scale;
    scaled = constrain(scaled, 0.0f, 65535.0f);
    return (uint16_t)(scaled + 0.5f);
  }

  uint8_t percentToU8(float pct) {
    pct = constrain(pct, 0.0f, 255.0f);
    return (uint8_t)(pct + 0.5f);
  }

  void notifySystemStatus() {
    SystemStatusPacket pkt;
    pkt.calibrated = lastCalibrated ? 1 : 0;
    pkt.trackingActive = lastTrackingActive ? 1 : 0;
    systemStatusChr.write((uint8_t*)&pkt, sizeof(pkt));
    if (Bluefruit.connected()) {
      systemStatusChr.notify((uint8_t*)&pkt, sizeof(pkt));
    }
  }

  // Comando ricevuto dal client: 0x01 = START, 0x00 = STOP, 0x02 =
  // CALIBRATE. Il callback gira nel contesto dello scheduler BLE: si
  // limita a impostare un flag, l'azione vera e propria (reset stato,
  // aggiornamento LED/status) la fa il loop principale.
  void command_write_callback(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
    (void) conn_hdl; (void) chr;
    if (len < 1) return;
    if (data[0] == 0x01) startRequested = true;
    else if (data[0] == 0x00) stopRequested = true;
    else if (data[0] == 0x02) calibrateRequested = true;
  }

  // RuntimeConfig (unita' fisiche, MotionTracker.h) <-> RuntimeConfigPacket
  // (fixed-point sul filo, BleServer.h) - stesso schema toFixed16/
  // toFixedU16 sopra, ma senza segno (nessun campo di Config e' negativo).
  RuntimeConfigPacket configToPacket(const RuntimeConfig& cfg) {
    RuntimeConfigPacket pkt;
    pkt.repDirection = (uint8_t)cfg.repDirection;
    pkt.phaseStartVelocityMmps = toFixedU16(cfg.phaseStartVelocityMps, 1000.0f);
    pkt.minPhaseDurationMs = toFixedU16(cfg.minPhaseDurationS, 1000.0f);
    pkt.maxPhaseDurationMs = toFixedU16(cfg.maxPhaseDurationS, 1000.0f);
    pkt.maxPlausibleVelocityMmps = toFixedU16(cfg.maxPlausibleVelocityMps, 1000.0f);
    pkt.zeroCrossConfirmSamples = cfg.zeroCrossConfirmSamples;
    pkt.returnPhaseTimeoutMs = toFixedU16(cfg.returnPhaseTimeoutS, 1000.0f);
    pkt.shockJerkThreshold = toFixedU16(cfg.shockJerkThresholdMps2, 100.0f);
    pkt.inPhaseMinFlatWindowMs = toFixedU16(cfg.inPhaseMinFlatWindowS, 1000.0f);
    pkt.returnFlatWindowMs = toFixedU16(cfg.returnFlatWindowS, 1000.0f);
    pkt.accZBiasIdleStillTimeMs = toFixedU16(cfg.accZBiasIdleStillTimeS, 1000.0f);
    pkt.debugLogEnabled = cfg.debugLogEnabled ? 1 : 0;
    return pkt;
  }

  RuntimeConfig packetToConfig(const RuntimeConfigPacket& pkt) {
    RuntimeConfig cfg;
    cfg.repDirection = (pkt.repDirection == 1) ? RepDirection::Down : RepDirection::Up;
    cfg.phaseStartVelocityMps = pkt.phaseStartVelocityMmps / 1000.0f;
    cfg.minPhaseDurationS = pkt.minPhaseDurationMs / 1000.0f;
    cfg.maxPhaseDurationS = pkt.maxPhaseDurationMs / 1000.0f;
    cfg.maxPlausibleVelocityMps = pkt.maxPlausibleVelocityMmps / 1000.0f;
    cfg.zeroCrossConfirmSamples = pkt.zeroCrossConfirmSamples;
    cfg.returnPhaseTimeoutS = pkt.returnPhaseTimeoutMs / 1000.0f;
    cfg.shockJerkThresholdMps2 = pkt.shockJerkThreshold / 100.0f;
    cfg.inPhaseMinFlatWindowS = pkt.inPhaseMinFlatWindowMs / 1000.0f;
    cfg.returnFlatWindowS = pkt.returnFlatWindowMs / 1000.0f;
    cfg.accZBiasIdleStillTimeS = pkt.accZBiasIdleStillTimeMs / 1000.0f;
    cfg.debugLogEnabled = pkt.debugLogEnabled != 0;
    return cfg;
  }

  // Aggiorna il valore GATT Read della Config characteristic (letto dal
  // client su ogni nuova connessione o su richiesta esplicita) - non emette
  // Notify: a differenza di Battery/SystemStatus, il client scrive lui
  // stesso i cambi di configurazione, non ha bisogno di essere avvisato di
  // un cambiamento che ha appena causato lui.
  void writeConfigCharacteristic(const RuntimeConfig& cfg) {
    RuntimeConfigPacket pkt = configToPacket(cfg);
    configChr.write((uint8_t*)&pkt, sizeof(pkt));
  }

  // Nuova configurazione scritta dal client sulla Config characteristic: si
  // limita a impostare un flag/valore in attesa, come command_write_callback
  // sopra - l'applicazione vera (MotionTracker::setConfig()) la fa il loop
  // principale tramite BleServer::takeConfigUpdate(). Aggiorna comunque
  // SUBITO il valore Read (vedi writeConfigCharacteristic sopra), cosi' una
  // Read immediatamente successiva alla Write vede gia' l'eco di quanto
  // appena scritto, anche prima che il loop principale l'abbia consumata.
  void config_write_callback(uint16_t conn_hdl, BLECharacteristic* chr, uint8_t* data, uint16_t len) {
    (void) conn_hdl; (void) chr;
    if (len < sizeof(RuntimeConfigPacket)) return;
    RuntimeConfigPacket pkt;
    memcpy(&pkt, data, sizeof(pkt));
    pendingConfig = packetToConfig(pkt);
    configUpdateAvailable = true;
    writeConfigCharacteristic(pendingConfig);
  }

  void connect_callback(uint16_t conn_handle) {
    // StreamPacket e' 36 byte: con l'MTU di default (23 byte) non
    // entrerebbe comunque in una singola notifica. Si richiede al client
    // il massimo supportato; se il client non lo concede, il notify()
    // fallira' finche' l'MTU non e' sufficiente.
    BLEConnection* connection = Bluefruit.Connection(conn_handle);
    connection->requestDataLengthUpdate();
    connection->requestMtuExchange(247);

    // Ad ogni connessione stabilita, il client deve sapere subito se il
    // sistema e' calibrato e se il tracciamento e' attivo.
    notifySystemStatus();
  }

  void disconnect_callback(uint16_t conn_handle, uint8_t reason) {
    (void) conn_handle; (void) reason;
  }
}

void BleServer::begin() {
  // Va chiamato prima di begin(): alloca banda/RAM sufficienti per MTU
  // grandi (richiesti sotto, in connect_callback) e code di notifica piu'
  // profonde, utile per lo streaming a ~20Hz di pacchetti da 36 byte.
  Bluefruit.configPrphBandwidth(BANDWIDTH_MAX);

  // begin(prph_count, central_count): solo 1 connessione peripheral verso
  // l'app, nessun ruolo central.
  Bluefruit.begin(1, 0);
  Bluefruit.setName("VBT-Sensor");
  Bluefruit.Periph.setConnectCallback(connect_callback);
  Bluefruit.Periph.setDisconnectCallback(disconnect_callback);

  // Abilita l'aggiornamento OTA (BLE DFU): scrivendo sulla sua
  // characteristic, il device si riavvia nel bootloader Adafruit di
  // fabbrica, che espone il vero servizio Secure DFU Nordic per il
  // trasferimento del nuovo firmware - vedi commento sull'include sopra.
  bledfu.begin();

  vbtService.begin();

  streamChr.setProperties(CHR_PROPS_NOTIFY);
  streamChr.setPermission(SECMODE_OPEN, SECMODE_NO_ACCESS);
  streamChr.setFixedLen(sizeof(StreamPacket));
  streamChr.begin();

  repSummaryChr.setProperties(CHR_PROPS_INDICATE);
  repSummaryChr.setPermission(SECMODE_OPEN, SECMODE_NO_ACCESS);
  repSummaryChr.setFixedLen(sizeof(RepSummaryPacket));
  repSummaryChr.begin();

  systemStatusChr.setProperties(CHR_PROPS_READ | CHR_PROPS_NOTIFY);
  systemStatusChr.setPermission(SECMODE_OPEN, SECMODE_NO_ACCESS);
  systemStatusChr.setFixedLen(sizeof(SystemStatusPacket));
  systemStatusChr.begin();
  notifySystemStatus(); // valore iniziale: non calibrato, non in tracciamento

  commandChr.setProperties(CHR_PROPS_WRITE);
  commandChr.setPermission(SECMODE_OPEN, SECMODE_OPEN);
  commandChr.setFixedLen(1);
  commandChr.begin();
  commandChr.setWriteCallback(command_write_callback);

  // Valore iniziale = i default compilati (vedi RuntimeConfig in
  // MotionTracker.h) - MotionTracker parte gia' con activeConfig=RuntimeConfig()
  // di default, quindi qui si limita a rispecchiare lo stesso stato via BLE,
  // senza bisogno di passare da takeConfigUpdate()/setConfig() per il valore
  // iniziale.
  configChr.setProperties(CHR_PROPS_READ | CHR_PROPS_WRITE);
  configChr.setPermission(SECMODE_OPEN, SECMODE_OPEN);
  configChr.setFixedLen(sizeof(RuntimeConfigPacket));
  configChr.begin();
  configChr.setWriteCallback(config_write_callback);
  writeConfigCharacteristic(MotionTracker::defaultConfig());

  // Servizi standard Bluetooth SIG (vedi commento sul layout in
  // BleServer.h) - battery aggiornata periodicamente da sendBattery(),
  // firmware version statica per tutta la sessione (mai un write).
  batteryService.begin();

  // setFirmwareRev() PRIMA di begin(): BLEDis::begin() e' quello che legge
  // il valore impostato e lo copia nella characteristic GATT vera e propria
  // (vedi BLEDis.cpp) - chiamato nell'ordine sbagliato, begin() troverebbe
  // ancora il default (versione del BOOTLOADER, non del nostro firmware) e
  // l'assegnazione qui sotto non avrebbe piu' alcun effetto.
  char fwVerStr[16];
  snprintf(fwVerStr, sizeof(fwVerStr), "%u.%u.%u",
           FirmwareVersion::MAJOR, FirmwareVersion::MINOR, FirmwareVersion::PATCH);
  deviceInfoService.setFirmwareRev(fwVerStr);
  deviceInfoService.begin();

  Bluefruit.Advertising.addFlags(BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE);
  Bluefruit.Advertising.addTxPower();
  Bluefruit.Advertising.addService(vbtService);
  Bluefruit.Advertising.addName();
  Bluefruit.Advertising.restartOnDisconnect(true);
  Bluefruit.Advertising.setInterval(32, 244); // 0.625ms unit: 20ms..152.5ms
  Bluefruit.Advertising.setFastTimeout(30);
  Bluefruit.Advertising.start(0); // 0 = pubblicita' senza timeout
}

bool BleServer::connected() {
  return Bluefruit.connected();
}

void BleServer::updateSystemStatus(bool calibrated, bool trackingActive) {
  lastCalibrated = calibrated;
  lastTrackingActive = trackingActive;
  notifySystemStatus();
}

void BleServer::sendStream(const MotionSample& s) {
  if (!Bluefruit.connected()) return;

  StreamPacket pkt;
  pkt.timestampMs = millis();
  pkt.linAccX = toFixed16(s.linAccX, 100.0f);
  pkt.linAccY = toFixed16(s.linAccY, 100.0f);
  pkt.linAccZ = toFixed16(s.linAccZ, 100.0f);
  pkt.worldAccX = toFixed16(s.worldAccX, 100.0f);
  pkt.worldAccY = toFixed16(s.worldAccY, 100.0f);
  pkt.worldAccZ = toFixed16(s.worldAccZ, 100.0f);
  pkt.worldVelX = toFixed16(s.worldVelX, 1000.0f);
  pkt.worldVelY = toFixed16(s.worldVelY, 1000.0f);
  pkt.refVelZ = toFixed16(s.refVelZ, 1000.0f);
  pkt.worldPosX = toFixed16(s.worldPosX, 1000.0f);
  pkt.worldPosY = toFixed16(s.worldPosY, 1000.0f);
  pkt.worldPosZ = toFixed16(s.worldPosZ, 1000.0f);
  pkt.quatW = toFixed16(s.quatW, 10000.0f);
  pkt.quatX = toFixed16(s.quatX, 10000.0f);
  pkt.quatY = toFixed16(s.quatY, 10000.0f);
  pkt.quatZ = toFixed16(s.quatZ, 10000.0f);

  streamChr.notify((uint8_t*)&pkt, sizeof(pkt));
}

void BleServer::sendRepSummary(const RepResult& r) {
  if (!Bluefruit.connected()) return;

  RepSummaryPacket pkt;
  pkt.repNumber = r.repNumber;
  pkt.peakVelocity = toFixed16(r.peakVelocity, 1000.0f);
  pkt.meanVelocity = toFixed16(r.meanVelocity, 1000.0f);
  pkt.peakAcceleration = toFixed16(r.peakAcceleration, 100.0f);
  pkt.meanAcceleration = toFixed16(r.meanAcceleration, 100.0f);
  pkt.displacementM = toFixedU16(r.displacementM, 1000.0f);
  pkt.quality1 = r.quality1;
  pkt.quality2 = r.quality2;
  pkt.quality3 = r.quality3;
  pkt.quality4 = r.quality4;

  repSummaryChr.indicate((uint8_t*)&pkt, sizeof(pkt));
}

void BleServer::sendBattery(float percent) {
  uint8_t pct = percentToU8(percent);

  batteryService.write(pct);
  if (Bluefruit.connected()) {
    batteryService.notify(pct);
  }
}

bool BleServer::takeStartRequested() {
  if (!startRequested) return false;
  startRequested = false;
  return true;
}

bool BleServer::takeStopRequested() {
  if (!stopRequested) return false;
  stopRequested = false;
  return true;
}

bool BleServer::takeCalibrateRequested() {
  if (!calibrateRequested) return false;
  calibrateRequested = false;
  return true;
}

bool BleServer::takeConfigUpdate(RuntimeConfig& outConfig) {
  if (!configUpdateAvailable) return false;
  configUpdateAvailable = false;
  outConfig = pendingConfig;
  return true;
}
