/*
  VBT Rep Counter & Velocity Estimator - v3 (BLE)
  Target: Seeed XIAO nRF52840 Sense (IMU LSM6DS3TR-C integrato)

  Il codice e' organizzato in moduli (un file .h/.cpp per responsabilita'),
  questo .ino contiene solo l'orchestrazione ad alto livello:

    Config.h          - pin e costanti condivise
    StatusLED         - LED RGB, ricalcolato ad ogni loop() dallo stato
                         corrente (vedi StatusLED.h per la tabella colori)
    BatteryMonitor     - lettura/percentuale LiPo 3.7V 360mAh
    PowerManager       - switch di accensione + deep sleep (System OFF)
    MadgwickAHRS       - filtro di orientamento (quaternione)
    MotionTracker      - lettura IMU, rotazione mondo, integrazione velocita'/
                         posizione, identificazione fasi/rep (vedi MotionTracker.h)
    BleServer          - servizio BLE custom (streaming + comandi), ruolo PERIPHERAL

  Libreria richiesta: "Seeed Arduino LSM6DS3" by Seeed Studio (la libreria
  BLE, Bluefruit52Lib, e' gia' inclusa nel board package Seeeduino:nrf52).

  Switch di accensione: collegare uno switch tra WAKE_PIN (D6, vedi
  Config.h) e GND. Switch chiuso = acceso; switch aperto = deep sleep,
  risveglio con reset completo alla richiusura. Il BLE (Bluefruit.begin())
  va avviato PRIMA di ogni possibile chiamata a goToSleep(): il deep sleep
  usa sd_power_system_off(), che richiede il SoftDevice gia' attivo.

  Flusso BLE (vedi BleServer.h per il layout esatto dei pacchetti):
  - SystemStatus e' leggibile in ogni momento con una GATT Read standard
    (oltre al push automatico via Notify ad ogni connessione e ad ogni
    cambio di stato).
  - La calibrazione dell'orientamento va richiesta esplicitamente con il
    comando CALIBRATE (0x02) quando SystemStatus segnala calibrated=false.
    START (0x01) viene ignorato se il sistema non e' ancora calibrato;
    CALIBRATE viene ignorato se il tracciamento e' attivo (va fermato
    prima con STOP, 0x00).
  - Mentre il tracciamento e' attivo: streaming veloce decimato
    (accelerazione body-frame e world-frame, velocita' e spazio world-frame
    sui 3 assi, quaternione) + un pacchetto RepSummary (Notify, senza ack
    GATT - vedi BleServer::sendRepSummary()) ad ogni FASE valida completata
    (una rep = una fase, nella direzione configurata - vedi Config sotto e
    la logica di apertura/chiusura fase documentata in MotionTracker.h/.cpp).
    Le fasi troppo brevi (probabile rimbalzo/rumore) sono scartate
    internamente, mai riportate.
    Il tracciamento continua anche attraverso una disconnessione/
    riconnessione BLE: non viene mai fermato automaticamente lato firmware.
  - Config (Read/Write): parametri dell'algoritmo regolabili a runtime
    (direzione rep Up/Down, anti-rimbalzo, soglie di fase - vedi
    RuntimeConfig in MotionTracker.h) - consumati qui sotto con
    BleServer::takeConfigUpdate()/MotionTracker::setConfig(). NON
    persistiti in flash: ad ogni riavvio si riparte dai default compilati.
  - Ogni 30 secondi, indipendentemente dal tracciamento: stato batteria
    (Battery Service standard, vedi BleServer.h).
*/

#include <Adafruit_TinyUSB.h>
#include "Config.h"
#include "StatusLED.h"
#include "BatteryMonitor.h"
#include "PowerManager.h"
#include "MotionTracker.h"
#include "BleServer.h"

unsigned long lastBatteryCheckTime = 0;
uint8_t streamDecimationCounter = 0;

void setup() {
  PowerManager::begin();
  StatusLED::begin();
  BatteryMonitor::begin();

  Serial.begin(115200);
  while (!Serial && millis() < 3000) { }

  // DIAGNOSTICA TEMPORANEA per isolare il problema del wake-from-sleep:
  // rimuovere una volta risolto. Il caso DOG e' quello che confermerebbe
  // (o smentirebbe, se non si presenta mai piu') l'ipotesi di un hang del
  // firmware salvato dal watchdog appena aggiunto (vedi PowerManager.h).
  Serial.print("RESETREAS = 0x");
  Serial.print(PowerManager::lastResetReason(), HEX);
  if (PowerManager::lastResetReason() & POWER_RESETREAS_OFF_Msk) {
    Serial.println(" -> risveglio da System OFF via GPIO (SENSE/DETECT) OK");
  } else if (PowerManager::lastResetReason() & POWER_RESETREAS_DOG_Msk) {
    Serial.println(" -> RESET DA WATCHDOG: il firmware era bloccato (hang/crash) e si e' auto-ripristinato");
  } else if (PowerManager::lastResetReason() & POWER_RESETREAS_LOCKUP_Msk) {
    Serial.println(" -> RESET DA CPU LOCKUP: hard fault non gestito");
  } else if (PowerManager::lastResetReason() == 0) {
    Serial.println(" -> POWER-ON RESET vero (alimentazione ricollegata da zero, non un wake da sleep)");
  } else {
    Serial.println(" -> altro motivo (vedi commento in PowerManager.cpp per i bit)");
  }

  // BLE va avviato PRIMA di ogni possibile goToSleep(): sd_power_system_off()
  // richiede il SoftDevice gia' attivo per funzionare in modo affidabile.
  BleServer::begin();
  BleServer::updateSystemStatus(false, false);

  // Se lo switch NON e' chiuso appena all'avvio, si riaddormenta subito
  if (!PowerManager::wakeSwitchClosed()) {
    PowerManager::goToSleep();
  }

  if (!MotionTracker::begin()) {
    Serial.println("ERRORE: IMU non inizializzato.");
    while (1) {
      // Il LED continua a riflettere connessione/stato anche in errore
      // (lampeggia giallo se non connesso, fisso giallo se connesso).
      StatusLED::update(BleServer::connected(), false, false);
      delay(100);
    }
  }

  lastBatteryCheckTime = millis();
}

void loop() {
  // Nutre il watchdog (vedi PowerManager.h): va chiamato ad ogni giro,
  // per primo, cosi' che QUALUNQUE blocco piu' avanti nel loop (incluso
  // uno dentro goToSleep() stesso, se lo switch e' aperto) resti scoperto
  // e porti al reset automatico entro il timeout.
  PowerManager::feedWatchdog();

  // Switch aperto -> torna a dormire
  if (!PowerManager::wakeSwitchClosed()) {
    PowerManager::goToSleep();
  }

  // --- LED: ricalcolato ogni ciclo dallo stato corrente (vedi StatusLED.h) ---
  StatusLED::update(BleServer::connected(), MotionTracker::isCalibrated(), MotionTracker::isTrackingActive());

  // --- Comandi ricevuti via BLE ---
  if (BleServer::takeCalibrateRequested()) {
    if (MotionTracker::isTrackingActive()) {
      Serial.println("CALIBRATE ignorato: ferma il tracciamento (STOP) prima di ricalibrare.");
    } else {
      MotionTracker::calibrateOrientation();
      BleServer::updateSystemStatus(true, false);
      Serial.println("Calibrazione completata.");
    }
  }
  if (BleServer::takeStartRequested()) {
    if (!MotionTracker::isCalibrated()) {
      Serial.println("START ignorato: calibra il dispositivo prima (comando CALIBRATE).");
    } else {
      MotionTracker::setTrackingActive(true);
      BleServer::updateSystemStatus(true, true);
    }
  }
  if (BleServer::takeStopRequested()) {
    MotionTracker::setTrackingActive(false);
    BleServer::updateSystemStatus(MotionTracker::isCalibrated(), false);
  }
  RuntimeConfig newConfig;
  if (BleServer::takeConfigUpdate(newConfig)) {
    MotionTracker::setConfig(newConfig);
    Serial.println("MotionTracker: nuova configurazione applicata via BLE.");
  }

  // --- Stato batteria, ogni 30 secondi (indipendente dal tracciamento) ---
  unsigned long now = millis();
  if (now - lastBatteryCheckTime >= Config::BATTERY_CHECK_INTERVAL_MS) {
    lastBatteryCheckTime = now;
    float vbat = BatteryMonitor::readVoltage();
    float pct = BatteryMonitor::voltageToPercent(vbat);
    Serial.print("Batteria: ");
    Serial.print(vbat, 2);
    Serial.print(" V (");
    Serial.print(pct, 0);
    Serial.print("%)");
    Serial.println(BatteryMonitor::isCharging() ? " [in carica]" : "");
    BleServer::sendBattery(pct);
  }

  // --- Orientamento/moto: sempre aggiornato (100Hz interno) ---
  // update() si autolimita a 100Hz e ritorna true SOLO quando ha calcolato
  // un campione vero: tutto cio' che deve avvenire "una volta per campione"
  // (decimazione streaming BLE) va gated su questo, altrimenti loop() (che
  // gira molto piu' veloce di 100Hz) ripete piu' volte lo stesso campione
  // stantio tra un aggiornamento vero e il successivo.
  bool newSample = MotionTracker::update();

  if (newSample && MotionTracker::isTrackingActive()) {
    // Dati di fine fase PRIMA dello streaming: entrambi passano dalla stessa
    // coda di notifiche BLE (vedi commento sul valore di ritorno in
    // BleServer::sendRepSummary()), e con Notify (fire-and-forget, non piu'
    // Indicate) un pacchetto perso per coda piena non viene ritrasmesso -
    // meglio che sia lo Stream, decimato e continuo, a perdere un campione
    // piuttosto che il resoconto di fase, che e' unico e non recuperabile.
    // Le fasi troppo brevi (vedi MIN_PHASE_DURATION_S in MotionTracker.cpp)
    // sono gia' scartate internamente: takeCompletedRep() ritorna true solo
    // per fasi valide.
    RepResult rep;
    if (MotionTracker::takeCompletedRep(rep)) {
      BleServer::sendRepSummary(rep);
    }

    // Streaming veloce, decimato rispetto ai 100Hz interni - disattivato
    // mentre il log dati grezzi su Serial e' attivo (RuntimeConfig::
    // debugLogEnabled): quel log e' gia' a 100Hz (5x piu' fitto di questo
    // stream a 20Hz), quindi ridondante, e la sua notify() competerebbe per
    // lo stesso ciclo di loop() proprio mentre si cerca la cattura piu'
    // pulita possibile (vedi commento sulla dichiarazione del flag,
    // MotionTracker.h).
    streamDecimationCounter++;
    if (streamDecimationCounter >= Config::STREAM_DECIMATION_FACTOR) {
      streamDecimationCounter = 0;
      if (!MotionTracker::currentConfig().debugLogEnabled) {
        BleServer::sendStream(MotionTracker::currentSample());
      }
    }
  }
}
