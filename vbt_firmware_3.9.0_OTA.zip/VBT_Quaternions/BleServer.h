#ifndef BLE_SERVER_H
#define BLE_SERVER_H

#include <Arduino.h>
#include "MotionTracker.h"

// Server BLE. Il servizio CUSTOM (vedi UUID_SERVICE in BleServer.cpp) ha 6
// characteristic:
//
//   Stream        (Notify)   - telemetria veloce, decimata (vedi Config.h),
//                               inviata solo mentre il tracciamento e' attivo
//   RepSummary    (Notify)   - un pacchetto per ogni rep completata (v3.0.0:
//                               una rep = una fase concentrica, l'eccentrica
//                               non e' piu' tracciata - vedi MotionTracker.cpp).
//                               Fire-and-forget,
//                               nessuna conferma GATT: indicate() bloccava
//                               l'intero loop() (quindi anche il
//                               campionamento IMU) in attesa dell'ack del
//                               client, nel caso peggiore fino al reset da
//                               watchdog - vedi sendRepSummary() in
//                               BleServer.cpp. L'eventuale continuita' va
//                               verificata lato app su pkt.repNumber.
//   SystemStatus  (Read/Notify) - calibrato/non calibrato, tracciamento
//                               attivo/fermo. Push automatico (Notify) ad
//                               ogni connessione stabilita e ad ogni cambio
//                               di stato; il client puo' anche interrogarlo
//                               in qualsiasi momento con una GATT Read
//                               standard (proprieta' Read), senza aspettare
//                               un evento - la characteristic mantiene
//                               sempre l'ultimo valore scritto
//   Command       (Write)    - 0x01 = START, 0x00 = STOP tracciamento,
//                               0x02 = CALIBRATE (ricalibra l'orientamento)
//   Config        (Read/Write) - parametri dell'algoritmo regolabili a
//                               runtime (vedi RuntimeConfig in
//                               MotionTracker.h) - direzione rep (Up/Down),
//                               anti-rimbalzo, soglie di fase, log
//                               diagnostico su Serial (debugLogEnabled). NON
//                               persistita in flash: ad ogni riavvio il
//                               firmware riparte dai default compilati,
//                               l'app e' responsabile di re-inviare
//                               l'ultima configurazione usata ad ogni nuova
//                               connessione. Read restituisce sempre la
//                               configurazione ATTIVA in questo momento.
//
// Battery e FirmwareVersion usano invece i servizi STANDARD Bluetooth SIG
// (riconosciuti nativamente da qualunque tool BLE, incluso nRF Connect),
// tramite le classi gia' incluse in Bluefruit52Lib:
//   BLEBas (Battery Service, 0x180F / Battery Level 0x2A19, Read/Notify,
//           1 byte percentuale 0-100 - il formato standard non include la
//           tensione, che quindi non e' piu' trasmessa via BLE)
//   BLEDis (Device Information Service, 0x180A / Firmware Revision String
//           0x2A26, Read, stringa "MAJOR.MINOR.PATCH" - statica per tutta
//           la sessione, valorizzata una sola volta in BleServer::begin()
//           dalle costanti di Config.h)
//
// A parte, il bootloader Adafruit espone anche il servizio "buttonless DFU"
// (classe BLEDfu della stessa Bluefruit52Lib, abilitata in BleServer::begin()):
// l'app scrive li' per far riavviare il device in modalita' bootloader, che
// poi espone il vero servizio Secure DFU Nordic per il trasferimento del
// firmware - gestito interamente dalla libreria DFU lato app (es. nordic_dfu
// su Flutter), MAI da codice custom qui.
//
// Layout binario dei pacchetti (little-endian, come tutta la piattaforma
// nRF52 / BLE): vedi le struct sotto. Il client deve conoscere questo
// layout per fare il parsing.
//
// Tutte le grandezze fisiche sono trasmesse come INTERI CON FATTORE DI
// SCALA FISSO (fixed-point), non float: dimezza/riduce il payload e
// funziona identicamente su qualunque piattaforma client (niente
// endianness/formato IEEE-754 da gestire). Per riottenere il valore
// fisico: valore_reale = raw / scala (vedi commento per campo e la
// tabella riassuntiva in fondo a questo file).
namespace BleServer {
  void begin();
  bool connected();

  // Da chiamare ad ogni cambio di stato calibrazione/tracciamento (anche
  // dal connect-callback, per inviare lo stato corrente al nuovo client).
  void updateSystemStatus(bool calibrated, bool trackingActive);

  void sendStream(const MotionSample& sample);
  void sendRepSummary(const RepResult& rep);
  // percent: 0-100, vedi BatteryMonitor::voltageToPercent() - la tensione
  // grezza non e' piu' trasmessa (il formato standard BLEBas e' un singolo
  // byte percentuale, vedi commento sul layout in cima al file).
  void sendBattery(float percent);

  // Comandi ricevuti dal client (scritti sulla Command characteristic),
  // da consumare nel loop principale. Ogni chiamata "take" ritorna true
  // al massimo una volta per comando ricevuto.
  bool takeStartRequested();
  bool takeStopRequested();
  bool takeCalibrateRequested();

  // Nuova configurazione ricevuta dal client (scritta sulla Config
  // characteristic), da consumare nel loop principale con
  // MotionTracker::setConfig(outConfig) - stesso schema "take" dei comandi
  // sopra. Ritorna true al massimo una volta per scrittura ricevuta.
  bool takeConfigUpdate(RuntimeConfig& outConfig);
}

#pragma pack(push, 1)

struct StreamPacket {
  uint32_t timestampMs;                    // ms, invariato
  int16_t linAccX, linAccY, linAccZ;       // x100  -> m/s^2 (risoluzione 0.01 m/s^2)
  int16_t worldAccX, worldAccY, worldAccZ; // x100  -> m/s^2
  int16_t worldVelX, worldVelY;            // x1000 -> m/s   (risoluzione 1 mm/s) - solo streaming/debug, nessun ruolo in fasi/rep
  int16_t refVelZ;                         // x1000 -> m/s   (unica pista verticale, decide anche apertura/chiusura fase - vedi MotionTracker.cpp)
  int16_t worldPosX, worldPosY, worldPosZ; // x1000 -> m     (risoluzione 1 mm)
  int16_t quatW, quatX, quatY, quatZ;      // x10000 -> adimensionale, range [-1,1]
}; // 4 + 12*2 + 3*2 + 4*2 = 36 byte

struct RepSummaryPacket {
  // repNumber: numero di rep INTERO 1-based (una rep = una fase concentrica,
  // v3.0.0 non traccia piu' l'eccentrica).
  uint8_t repNumber;
  int16_t peakVelocity;     // x1000 -> m/s
  int16_t meanVelocity;     // x1000 -> m/s
  int16_t peakAcceleration; // x100  -> m/s^2
  int16_t meanAcceleration; // x100  -> m/s^2
  uint16_t displacementM;   // x1000 -> m (risoluzione 1mm), sempre >=0: spazio percorso in QUESTA fase
  // quality1: CONFIDENCE della fase, 0-100 - coefficiente cinematico
  // (displacementM vs meanVelocity*durata fase, vedi closePhase() in
  // MotionTracker.cpp).
  // quality2..4: placeholder, algoritmo di scoring non ancora definito.
  uint8_t quality1;
  uint8_t quality2;
  uint8_t quality3;
  uint8_t quality4;
}; // 1 + 4*2 + 2 + 4 = 15 byte

struct SystemStatusPacket {
  uint8_t calibrated;     // 0/1
  uint8_t trackingActive; // 0/1
}; // 2 byte (invariato)

// Layout della Config characteristic (Read/Write) - specchio di
// RuntimeConfig (MotionTracker.h) in formato fixed-point, stesso schema
// delle altre characteristic. repDirection/zeroCrossConfirmSamples sono gia'
// interi diretti (non serve scala); le durate sono in millisecondi, le
// velocita' in mm/s - piu' che sufficiente risoluzione per soglie
// dell'ordine di 0.1-5 m/s e 0.3-5 s.
struct RuntimeConfigPacket {
  uint8_t repDirection;              // 0=Up, 1=Down
  uint16_t phaseStartVelocityMmps;   // x1 -> mm/s
  uint16_t minPhaseDurationMs;       // x1 -> ms
  uint16_t maxPhaseDurationMs;       // x1 -> ms
  uint16_t maxPlausibleVelocityMmps; // x1 -> mm/s
  uint8_t zeroCrossConfirmSamples;   // diretto
  uint16_t returnPhaseTimeoutMs;     // x1 -> ms
  uint16_t shockJerkThreshold;       // x100 -> m/s^2
  uint16_t inPhaseMinFlatWindowMs;   // x1 -> ms
  uint16_t returnFlatWindowMs;       // x1 -> ms
  uint16_t accZBiasIdleStillTimeMs;  // x1 -> ms - vedi RuntimeConfig::accZBiasIdleStillTimeS, MotionTracker.h
  uint8_t debugLogEnabled;           // 0/1 - vedi RuntimeConfig::debugLogEnabled, MotionTracker.h
}; // 1 + 2*8 + 1 + 2 + 1 = 21 byte

#pragma pack(pop)

// ============================================================================
// TABELLA RIASSUNTIVA: characteristic / composizione messaggio / scala
// ============================================================================
//
// Stream (Notify, 36 byte):
//   timestampMs      uint32  ms (diretto)
//   linAccX/Y/Z      int16   x100   -> m/s^2   (accelerazione lineare, sensore)
//   worldAccX/Y/Z    int16   x100   -> m/s^2   (accelerazione, mondo)
//   worldVelX/Y      int16   x1000  -> m/s     (velocita', mondo - solo streaming/debug, nessun ruolo in fasi/rep)
//   refVelZ          int16   x1000  -> m/s     (unica pista verticale - decide anche apertura/chiusura fase)
//   worldPosX/Y/Z    int16   x1000  -> m       (spazio, mondo)
//   quatW/X/Y/Z      int16   x10000 -> [-1,1]  (quaternione orientamento)
//
// RepSummary (Notify, 15 byte):
//   repNumber        uint8   diretto -> rep 1-based (una rep = una fase concentrica)
//   peakVelocity     int16   x1000  -> m/s
//   meanVelocity     int16   x1000  -> m/s
//   peakAcceleration int16   x100   -> m/s^2
//   meanAcceleration int16   x100   -> m/s^2
//   displacementM    uint16  x1000  -> m (spazio percorso in questa fase, sempre >=0)
//   quality1         uint8   0-100: coefficiente cinematico (vedi closePhase() in MotionTracker.cpp)
//   quality2..4      uint8   diretto, 0-100 (placeholder, sempre 0)
//
// Battery (Read/Notify, 3 byte):
//   voltageMv        uint16  diretto -> mV (dividere per 1000 per Volt)
//   percent          uint8   diretto -> 0-100
//
// SystemStatus (Read/Notify, 2 byte):
//   calibrated       uint8   0/1
//   trackingActive   uint8   0/1
//
// Command (Write, 1 byte):
//   0x00 STOP, 0x01 START, 0x02 CALIBRATE
//
// Config (Read/Write, 21 byte) - vedi RuntimeConfig in MotionTracker.h:
//   repDirection              uint8   0=Up, 1=Down
//   phaseStartVelocityMmps    uint16  x1    -> mm/s
//   minPhaseDurationMs        uint16  x1    -> ms
//   maxPhaseDurationMs        uint16  x1    -> ms
//   maxPlausibleVelocityMmps  uint16  x1    -> mm/s
//   zeroCrossConfirmSamples   uint8   diretto
//   returnPhaseTimeoutMs      uint16  x1    -> ms
//   shockJerkThreshold        uint16  x100  -> m/s^2
//   inPhaseMinFlatWindowMs    uint16  x1    -> ms
//   returnFlatWindowMs        uint16  x1    -> ms
//   accZBiasIdleStillTimeMs   uint16  x1    -> ms
//   debugLogEnabled           uint8   0/1
//
// ============================================================================
// SERVIZI STANDARD (Bluetooth SIG) - vedi commento in cima al file
// ============================================================================
//
// Battery Service (0x180F) / Battery Level (0x2A19) - Read/Notify, 1 byte:
//   percent          uint8   diretto -> 0-100
//
// Device Information Service (0x180A) / Firmware Revision String (0x2A26) -
// Read, stringa UTF-8 (NON fixed-point) tipo "3.1.0" - lunghezza variabile,
// vedi FirmwareVersion in Config.h per come viene composta.

#endif
