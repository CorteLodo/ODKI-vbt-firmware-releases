#ifndef MOTION_TRACKER_H
#define MOTION_TRACKER_H

#include <Arduino.h>

// Campione di moto aggiornato ad ogni ciclo (100Hz). linAcc* = accelerazione
// nel sistema del sensore (gravita' rimossa). world* = stesse grandezze nel
// sistema del mondo (assi fissi). refVelZ/worldPosZ (asse verticale usato
// per fasi/rep) valgono SOLO mentre una fase concentrica e' aperta - vedi
// trueVelZ in MotionTracker.cpp per la pista interna, sempre integrata, da
// cui refVelZ e' derivata. X/Y non hanno un ruolo nelle fasi/rep, restano
// solo per streaming/debug.
struct MotionSample {
  float linAccX = 0, linAccY = 0, linAccZ = 0;
  float worldAccX = 0, worldAccY = 0, worldAccZ = 0;
  float worldVelX = 0, worldVelY = 0;
  float refVelZ = 0; // velocita' direzionata, valida solo a fase aperta - vedi commento sopra
  float worldPosX = 0, worldPosY = 0, worldPosZ = 0;
  float quatW = 1, quatX = 0, quatY = 0, quatZ = 0;
};

// Riepilogo di UNA rep = UNA fase concentrica (la sola tracciata da questa
// versione, vedi MotionTracker.cpp). Una fase inizia quando refVelZ supera
// PHASE_START_VELOCITY_MPS e finisce quando la velocita' torna a zero/
// negativa (fine del movimento concentrico) o per il Guard di piattezza.
// displacementM: spazio percorso durante la fase (sempre positivo).
// quality1: 0-100, coefficiente cinematico (vedi closePhase() in
// MotionTracker.cpp): confronta displacementM con la stima indipendente
// meanVelocity*durata fase - 100 = nessuno scarto, 0 = scarto relativo
// >=100%.
// quality2..4: placeholder, algoritmo di scoring non ancora definito.
struct RepResult {
  uint8_t repNumber = 0;
  float peakVelocity = 0;
  float meanVelocity = 0;
  float peakAcceleration = 0;
  float meanAcceleration = 0;
  float displacementM = 0;
  uint8_t quality1 = 0;
  uint8_t quality2 = 0;
  uint8_t quality3 = 0;
  uint8_t quality4 = 0;
};

// Stato del guard sulla velocita' (vedi MotionTracker.cpp), esposto per
// diagnostica.
struct MotionDebugState {
  float gyroMag = 0;  // modulo giroscopio, gradi/s
  float accZBias = 0; // stima corrente del bias di worldAccZ (m/s^2)

  // Guard sulla velocita': riportano SOLO l'evento del campione corrente
  // (si azzerano ad ogni update()).
  bool velocityClampedToMax = false;  // |refVelZ| ha superato il massimo plausibile ed e' stata limitata
  bool velocityForcedZeroFlat = false; // refVelZ era piatta (con accelerazione bassa) da troppi campioni consecutivi ed e' stata forzata a 0
  bool shockRejected = false; // worldAccZ di questo campione scartato per l'integrazione (jerk oltre soglia, vedi RuntimeConfig::shockJerkThresholdMps2)
};

// Direzione della fase tracciata come rep - vedi RuntimeConfig::repDirection
// e il commento su repDirectionSign in MotionTracker.cpp per come viene
// applicata internamente.
enum class RepDirection : uint8_t {
  Up = 0,   // fase concentrica positiva (es. squat, panca) - default
  Down = 1, // fase concentrica negativa (es. discesa controllata/eccentrica pura)
};

// Parametri dell'algoritmo regolabili a runtime via BLE (vedi Config
// characteristic in BleServer.h/.cpp) - NON persistiti in flash: ad ogni
// riavvio il firmware riparte dai DEFAULT compilati (vedi DEFAULT_CONFIG in
// MotionTracker.cpp); l'app e' responsabile di re-inviare l'ultima
// configurazione usata ad ogni nuova connessione, se diversa dai default.
struct RuntimeConfig {
  RepDirection repDirection = RepDirection::Up;
  // Soglia di velocita' (m/s, sempre positiva) oltre la quale si apre una
  // nuova fase - vedi PHASE_START_VELOCITY_MPS in MotionTracker.cpp.
  float phaseStartVelocityMps = 0.2f;
  // Una fase piu' corta di questa durata (secondi) e' scartata (probabile
  // rimbalzo/rumore, non un vero rep).
  float minPhaseDurationS = 0.35f;
  // Rete di sicurezza: chiusura forzata di una fase rimasta aperta oltre
  // questa durata (secondi), quality1 forzato a 0.
  float maxPhaseDurationS = 5.0f;
  // Limite fisico plausibile (m/s) su refVelZ, su ENTRAMBI i lati - oltre
  // questo e' sicuramente deriva, non moto vero.
  float maxPlausibleVelocityMps = 4.0f;
  // Campioni CONSECUTIVI di velocita' a/sotto zero richiesti per confermare
  // la fine del movimento concentrico (vedi ZERO_CROSS_CONFIRM_SAMPLES).
  uint8_t zeroCrossConfirmSamples = 3;
  // Rete di sicurezza per l'attesa del ritorno (vedi returnPhaseOpen in
  // MotionTracker.cpp): dopo la chiusura di una fase valida, una nuova fase
  // non puo' aprirsi finche' il movimento di ritorno (direzione opposta)
  // non si e' concluso per piattezza - MA se questa attesa supera questa
  // durata (secondi), si sblocca comunque (rep in continuo/touch-and-go,
  // senza una vera pausa tra una rep e l'altra).
  float returnPhaseTimeoutS = 2.0f;
  // Filtro anti-shock: variazione MASSIMA plausibile di worldAccZ da un
  // campione al successivo (m/s^2) - un urto meccanico produce un salto
  // quasi istantaneo, impossibile per una spinta muscolare vera (sempre
  // graduale). Oltre questa soglia il campione e' scartato per
  // l'integrazione (vedi il filtro in integrateMotion(), MotionTracker.cpp).
  // Tarato su dati reali: il moto vero piu' rapido osservato resta sotto i
  // 2.6 m/s^2/campione, un urto verificato arriva a 7.8 m/s^2/campione.
  float shockJerkThresholdMps2 = 4.5f;
  // Quanto a lungo (secondi) la velocita' puo' restare piatta MENTRE una
  // fase concentrica e' aperta prima che il Guard di piattezza la consideri
  // ferma/fase conclusa (vedi inPhaseMinFlatWindowSamples() in
  // MotionTracker.cpp) - il default (0.20s) e' pensato per rep normali,
  // senza pause volontarie. Per protocolli con una pausa isometrica A META'
  // della fase tracciata (es. sticking-point training, tempo con pausa a
  // meta' corsa) un default cosi' breve puo' far chiudere la fase durante
  // la pausa voluta, come se la rep fosse gia' finita: alzare questo valore
  // da' al Guard piu' pazienza in quel caso - ma solo FINO a 0.30s: e' il
  // tetto della finestra dinamica in fase (MAX_VELOCITY/ACCELERATION_
  // FLAT_WINDOW_SAMPLES in MotionTracker.cpp, condiviso con la fase
  // concentrica normale, non regolabile a se' stante), quindi valori piu'
  // alti vengono limitati li' senza avere ulteriore effetto. NON influisce
  // sull'attesa del ritorno tra una rep e l'altra (vedi
  // RuntimeConfig::returnFlatWindowS/returnPhaseTimeoutS sotto), ne' sulla
  // finestra usata in idle (fissa al minimo assoluto, non regolabile:
  // nessuna rep in corso da proteggere).
  float inPhaseMinFlatWindowS = 0.20f;
  // Quanto a lungo (secondi) trueVelZ deve restare piatta DURANTE l'attesa
  // del ritorno (returnPhaseOpen, tra la fine di una rep e l'apertura della
  // prossima) prima che il firmware sia ragionevolmente certo che il
  // bilanciere si sia davvero fermato e chiuda l'attesa - vedi
  // returnFlatWindowSamples() in MotionTracker.cpp. A differenza di
  // inPhaseMinFlatWindowS (dinamica, si restringe con la velocita' di
  // picco della fase): qui la finestra e' SEMPRE fissa a questo valore per
  // l'intera durata dell'attesa - non c'e' nessun picco di rep da
  // proteggere durante il ritorno, solo la certezza che serve prima di
  // azzerare trueVelZ. Default 0.30s (il vecchio comportamento, prima che
  // diventasse regolabile). Se l'attesa non si conclude MAI per piattezza
  // (rep in continuo/touch-and-go), resta comunque il timeout assoluto
  // RuntimeConfig::returnPhaseTimeoutS come rete di sicurezza.
  float returnFlatWindowS = 0.30f;
  // Tempo di quiete CONSECUTIVA (secondi) richiesto per aggiornare la stima
  // di accZBias (e del bias giroscopio) quando NON siamo dentro la fase
  // concentrica tracciata (fase gia' chiusa/attesa del ritorno/idle) - vedi
  // updateOrientationAndAcceleration() in MotionTracker.cpp. Piu' breve del
  // tempo fisso richiesto MENTRE la fase e' aperta (ACCZ_BIAS_GYRO_STILL_TIME,
  // 0.12s, non regolabile: durante la spinta vera un plateau di velocita' non
  // e' un buon momento per fidarsi del bias). Serve a recuperare una stima
  // aggiornata anche tra rep veloci/ravvicinate (es. touch-and-go) che non
  // lasciano mai una pausa lunga: senza, il bias resta congelato per l'intera
  // serie e ogni residuo si integra nella velocita' per tutta la durata di
  // ogni rep, con letture di picco incoerenti da una rep all'altra - sintomo
  // osservato su hardware, che spariva dopo una pausa lunga (l'unica finestra
  // abbastanza lunga da soddisfare i 0.12s fissi).
  float accZBiasIdleStillTimeS = 0.05f;
  // Log dati grezzi su Serial per analisi di laboratorio (OFF di default) -
  // UNA riga CSV per campione a 100Hz (tipo "S") + una riga per ogni fine
  // fase (tipo "R"), vedi logSampleCsv()/closePhase() in MotionTracker.cpp.
  // Va acceso solo con un host collegato che legga attivamente la seriale
  // (cattura da laboratorio): a 100Hz stampare costa CPU/energia ad ogni
  // ciclo, e se il buffer seriale si riempie (nessun host che legge)
  // Serial.print puo' bloccare e ritardare loop() - che ritarda il
  // campionamento stesso, gonfiando il prossimo dt e con esso l'integrazione.
  // Mentre e' attivo, lo streaming BLE decimato (Stream characteristic, 20Hz)
  // viene disattivato (vedi loop() in VBT_Quaternions.ino): e' ridondante col
  // log seriale, gia' a 100Hz, e la sua notify() competerebbe per lo stesso
  // ciclo di loop().
  bool debugLogEnabled = false;
};

namespace MotionTracker {
  bool begin();

  // ~2s da fermo: allinea l'orientamento alla gravita'. Bloccante.
  void calibrateOrientation();
  bool isCalibrated();

  // Azzera anche l'integrazione di velocita'/posizione e lo stato di
  // fasi/rep (nuova sessione pulita).
  void setTrackingActive(bool active);
  bool isTrackingActive();

  // Applica una nuova configurazione runtime (vedi RuntimeConfig sopra) -
  // richiamabile in qualunque momento, anche a tracciamento attivo (i nuovi
  // valori si applicano dal campione successivo). NON persiste in flash.
  void setConfig(const RuntimeConfig& config);
  const RuntimeConfig& currentConfig();
  // Valori compilati di fabbrica - usati dal firmware al boot e disponibili
  // all'app per un eventuale "reset ai default" lato UI.
  const RuntimeConfig& defaultConfig();

  // Da chiamare ad ogni loop(); si auto-limita a 100Hz INTERNAMENTE (se
  // chiamata piu' spesso, le chiamate in eccesso sono no-op e ritornano
  // false). Il chiamante deve guardare il valore di ritorno per sapere se
  // e' stato calcolato un campione VERO, e usarlo per gated qualunque cosa
  // debba avvenire "una volta per campione" (streaming BLE decimato, ecc.).
  bool update();

  const MotionSample& currentSample();

  // true se una fase VALIDA (durata > soglia minima) e' stata completata
  // dall'ultima chiamata (si consuma). Le fasi troppo brevi vengono
  // scartate silenziosamente (non richiamano mai true).
  bool takeCompletedRep(RepResult& outResult);

  const MotionDebugState& debugState();
}

#endif
